#!/usr/bin/env python3
"""Reassemble the single-file Provision & Clause Selector from src/.

Usage:  python build.py [output.html]

Layout: src/shell.html   page markup with a {{CSS}} placeholder
        src/styles.css   all styles
        src/prelude.txt  script header (matrix label globals)
        src/data/matrix.json  embedded matrix (regenerate when WarU updates)
        src/modules/NN_name.js  code modules; numeric prefix = load order

The output is byte-identical to the shipped single file; edit modules,
rebuild, and deploy the one HTML file as before (offline / NIPR-friendly).
"""
import os, sys, glob
here = os.path.dirname(os.path.abspath(__file__))
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "clause-selector.html")
shell = open(os.path.join(here, "src/shell.html")).read()
css = open(os.path.join(here, "src/styles.css")).read()
prelude = open(os.path.join(here, "src/prelude.txt")).read()
data = open(os.path.join(here, "src/data/matrix.json")).read()
mods = sorted(glob.glob(os.path.join(here, "src/modules/*.js")))
code = "".join(open(m).read() for m in mods)
html = (shell.replace("{{CSS}}", css)
        + "<script>\n" + prelude + "let DATA =\n" + data + ";" + code
        + "</script>\n</body>\n</html>")
open(out, "w").write(html)
print("built", out, "-", len(html), "bytes,", len(mods), "modules")
