

/* ============================================================================
   ARCHITECTURE — single-file by design (offline / NIPR-friendly), modular source
   01 pipeline   : matrix row processing, threshold & condition tagging
   02 xlsx       : zero-dependency .xlsx reader (runtime matrix updates)
   03 state      : profile questions (QS), refinement conditions (REF), constants
   04 wizard     : Phase 1 rendering
   05 refine     : Phase 2 rendering (condition screening UI)
   06 engine     : run() — gates, screening, companion cascade, restore/master
   07 fillins    : tokenizer, inline fill-in editor, completed-text copy
   08 rows       : badges, row templates, results rendering
   09 print      : ordering helpers + both contract attachments
   10 sections   : UCF grouping + Section I/K/L copy blocks
   11 records    : session save/load, CSV export
   12 validate   : known-list comparison + master IDIQ/BPA handling
   13 boot       : event wiring, initial render
   Build: edit src/ modules, run build.py to reassemble this file.
   ========================================================================= */
