/* ===== MODULE 01: pipeline ===== */
const THR_RE=/(?:exceed(?:s|ing)?|over|above|more than)\s+(?:the\s+)?\$\s?([\d][\d,\.]*)\s*(million)?/gi;
const SAT_RE=/(?:exceed(?:s|ing)?|over|above|more than)\s+the\s+simplified acquisition threshold/i;
const NEG_RE=/\b(unless|except|other than|are not|is not|do not|will not|not)\b/i;
const SBIR_PAT=/\bSBIR\b|Small Business Innovation Research|\bSTTR\b|Small Business Technology Transfer/gi;
const NEG_WIDE=/\b(unless|except|other than|does not apply|do not|will not|are not|is not|not|excluding)\b/i;
function findTagWide(text,rx){
  rx.lastIndex=0; let pos=false,neg=false,m;
  while((m=rx.exec(text))){
    if(NEG_WIDE.test(text.slice(Math.max(0,m.index-200),m.index)))neg=true; else pos=true;
    if(m.index===rx.lastIndex)rx.lastIndex++;
  }
  return pos?"pos":(neg?"neg":null);
}
const CONDS={
 setaside:/set.?aside|8\(a\)|HUBZone|service-disabled veteran-owned|economically disadvantaged women-owned|women-owned small business program/gi,
 tina:/certified cost or pricing data/gi,
 idiq:/indefinite.deliver|indefinite.quantity|task.or.delivery.order/gi,
 financing:/progress payments|performance-based payments|contract financing|advance payments?/gi,
 evms:/earned value|major system|major defense acquisition/gi,
 ittelecom:/information technology|telecommunications services|telecommunications equipment/gi,
 gfp:/government.?furnished propert|government property/gi,
 classified:/classified information|security clearance|access to classified|National Industrial Security/gi,
 hazmat:/hazardous material|ammunition and explosives/gi,
 domestic:/Buy American|Trade Agreements Act|trade agreements? (act|appl|certificate)|domestic end product|Berry Amendment|specialty metals/gi,
 personal:/personal services contract/gi,
 uca:/letter contract|undefinitized contract action|unpriced purchase order/gi,
 foreign:/outside the United States|in a foreign country/gi,
 cui:/covered defense information|controlled unclassified information|\bCUI\b|safeguarding covered|cyber incident|NIST SP 800-171|Cybersecurity Maturity Model|CMMC/gi,
 govsite:/Government installation|Federal facility|on a Government (site|facility|installation)|Government premises|military installation/gi,
 bonds:/performance bond|payment bond|bid guarantee|surety|bonds? (?:are|is) required/gi,
 warranty:/\bwarranty\b|\bwarranties\b/gi,
 techdata:/technical data|computer software|data rights|noncommercial computer software/gi,
 edunp:/educational institution|nonprofit organization/gi,
 sca:/Service Contract Labor Standards|Service Contract Act/gi,
 subkplan:/subcontracting plan/gi,
 fobor:/f\.?\s?o\.?\s?b\.?\s?origin/gi,
 fobdest:/f\.?\s?o\.?\s?b\.?\s?destination/gi,
 firstart:/first article/gi,
};
const NEVER_SCREEN={setaside:/subcontracting plan|liquidated damages.*subcontract|utilization of small/i};

function parseThr(text){
  let vals=[]; THR_RE.lastIndex=0; let m;
  while((m=THR_RE.exec(text))){
    let v=parseFloat(m[1].replace(/,/g,""));
    if(m[2])v*=1e6;
    if(!isNaN(v)&&v>=2000)vals.push(v);
  }
  if(vals.length)return Math.min(...vals);
  return SAT_RE.test(text)?350000:null;
}
function sentenceBefore(text,pos){
  const st=Math.max(text.lastIndexOf(".",pos),text.lastIndexOf(";",pos),0);
  return text.slice(st,pos);
}
function findTag(text,rx){
  rx.lastIndex=0; let pos=false,neg=false,m;
  while((m=rx.exec(text))){
    if(NEG_RE.test(sentenceBefore(text,m.index)))neg=true; else pos=true;
    if(m.index===rx.lastIndex)rx.lastIndex++;
  }
  return pos?"pos":(neg?"neg":null);
}
function computeTags(c){
  const text=c.presc+" "+(c.notes||[]).join(" ");
  const tags={};
  for(const [name,rx] of Object.entries(CONDS)){
    const t=findTag(text,rx);
    if(t){
      if(NEVER_SCREEN[name]&&NEVER_SCREEN[name].test(c.title))continue;
      tags[name]=t;
    }
  }
  if(tags.domestic&&tags.foreign)delete tags.foreign;
  if(!tags.subkplan&&/subcontracting plan/i.test(c.title))tags.subkplan="pos";
  const sb=findTagWide(text+" "+c.title,SBIR_PAT);
  if(sb)tags.sbir=sb;
  // known inverse cases: the general (non-SBIR) data clauses apply when the award is NOT SBIR
  if((c.cite==="52.227-14"||c.cite==="252.227-7014")&&tags.sbir)tags.sbir="neg";
  return tags;
}
const codeOf=v=>{const m=/^([RAO])/.exec((v||"").trim());return m?m[1]:"";};

// rawRows: array of {col->string} keyed by spreadsheet column number, rows 7+
function processRows(rawRows){
  const out=[]; let prev=null;
  for(const g of rawRows){
    const cite=(g[2]||"").trim(), title=(g[3]||"").trim();
    if(!cite&&!title)continue;
    const presc=(g[6]||"").trim(), full=(g[38]||"").trim(), pc=(g[7]||"").trim();
    const rec={cite,title,date:((g[4]||"")+"").trim().slice(0,12),
      presc_at:(g[5]||"").trim(),presc:presc.slice(0,1100),pc,cots_na:pc.includes("\u00fa"),
      rfo:(g[8]||"").trim(),iap:(g[9]||"").trim(),ibr:(g[10]||"").trim(),ucf:(g[12]||"").trim(),
      fp:codeOf(g[13]),cr:codeOf(g[14]),tm:codeOf(g[15]),
      p:{nsup:codeOf(g[16]),nsvc:codeOf(g[17]),rd:codeOf(g[18]),con:codeOf(g[19]),lmv:codeOf(g[20]),
         commsvc:codeOf(g[21]),ddr:codeOf(g[22]),ae:codeOf(g[23]),trn:codeOf(g[24]),utl:codeOf(g[25]),
         csup:codeOf(g[26]),csvc:codeOf(g[27])},
      sap:codeOf(g[28]),sld:codeOf(g[29]),neg:codeOf(g[30]),le350:codeOf(g[31]),
      nsubk:codeOf(g[32]),csubk:codeOf(g[33]),oconus:codeOf(g[34]),reg:(g[35]||"").trim(),
      alt:(g[41]||"").trim(),dev:(g[43]||"").trim(),
      thr:parseThr(presc),fill:false};
    if(full){
      if(full.length>=32767)rec.trunc=true;
      const tk=tokenizeFull(full.slice(0,40000),title);
      if(tk.some(t=>t.t==="b"||t.t==="cb")){rec.fill=true;rec.full=full.slice(0,40000);}
      else if(/^n/i.test(rec.ibr))rec.full=full.slice(0,40000);
    }
    if(cite.startsWith("See notes")||title.startsWith("See notes")){
      if(prev&&rec.presc){(prev.notes=prev.notes||[]).push(rec.presc.slice(0,700));}
      continue;
    }
    if(title==="RESERVED")continue;
    out.push(rec); prev=rec;
  }
  for(const c of out)c.tags=computeTags(c);
  return out;
}

