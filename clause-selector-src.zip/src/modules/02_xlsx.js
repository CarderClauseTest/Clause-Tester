/* ===== MODULE 02: xlsx ===== */
async function inflateRaw(bytes){
  const ds=new DecompressionStream("deflate-raw");
  const buf=await new Response(new Blob([bytes]).stream().pipeThrough(ds)).arrayBuffer();
  return new Uint8Array(buf);
}
async function unzip(buf){
  const u8=new Uint8Array(buf), dv=new DataView(buf);
  // find End of Central Directory
  let eocd=-1;
  for(let i=u8.length-22;i>=Math.max(0,u8.length-22-65536);i--){
    if(dv.getUint32(i,true)===0x06054b50){eocd=i;break;}
  }
  if(eocd<0)throw new Error("Not a valid .xlsx (zip) file");
  const count=dv.getUint16(eocd+10,true), cdOfs=dv.getUint32(eocd+16,true);
  const entries={}; let p=cdOfs;
  const td=new TextDecoder();
  for(let i=0;i<count;i++){
    if(dv.getUint32(p,true)!==0x02014b50)throw new Error("Bad central directory");
    const method=dv.getUint16(p+10,true), csize=dv.getUint32(p+20,true);
    const nlen=dv.getUint16(p+28,true), elen=dv.getUint16(p+30,true), clen=dv.getUint16(p+32,true);
    const lho=dv.getUint32(p+42,true);
    const name=td.decode(u8.subarray(p+46,p+46+nlen));
    entries[name]={method,csize,lho};
    p+=46+nlen+elen+clen;
  }
  async function read(name){
    const e=entries[name]; if(!e)return null;
    const nlen2=dv.getUint16(e.lho+26,true), elen2=dv.getUint16(e.lho+28,true);
    const start=e.lho+30+nlen2+elen2;
    const raw=u8.subarray(start,start+e.csize);
    if(e.method===0)return raw;
    if(e.method===8)return await inflateRaw(raw);
    throw new Error("Unsupported zip compression method "+e.method);
  }
  return {entries,read,text:async n=>{const b=await read(n);return b?new TextDecoder().decode(b):null;}};
}
function colToNum(ref){ // "AB12" -> 28
  let n=0;
  for(const ch of ref){const c=ch.charCodeAt(0);if(c>=65&&c<=90)n=n*26+(c-64);else break;}
  return n;
}
function excelDate(serial){
  const d=new Date(Date.UTC(1899,11,30)+serial*86400000);
  const M=["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
  return M[d.getUTCMonth()]+" "+d.getUTCFullYear();
}
async function parseXlsxMatrix(buf){
  const zip=await unzip(buf);
  const parser=new DOMParser();
  const wbXml=parser.parseFromString(await zip.text("xl/workbook.xml"),"application/xml");
  const relsXml=parser.parseFromString(await zip.text("xl/_rels/workbook.xml.rels"),"application/xml");
  const rels={};
  relsXml.querySelectorAll("Relationship").forEach(r=>rels[r.getAttribute("Id")]=r.getAttribute("Target"));
  let target=null, fallback=null;
  wbXml.querySelectorAll("sheet").forEach(sh=>{
    const t=rels[sh.getAttribute("r:id")||sh.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id")];
    if(!fallback)fallback=t;
    if(sh.getAttribute("name")==="Matrix")target=t;
  });
  target=target||fallback;
  if(!target)throw new Error("No worksheet found");
  if(!target.startsWith("xl/"))target="xl/"+target.replace(/^\//,"");
  // shared strings
  const sst=[]; const sstTxt=await zip.text("xl/sharedStrings.xml");
  if(sstTxt){
    const sx=parser.parseFromString(sstTxt,"application/xml");
    sx.querySelectorAll("si").forEach(si=>{
      let s=""; si.querySelectorAll("t").forEach(t=>s+=t.textContent); sst.push(s);
    });
  }
  const shXml=parser.parseFromString(await zip.text(target),"application/xml");
  const rows=[]; const rowMap={};
  shXml.querySelectorAll("row").forEach(row=>{
    const r=parseInt(row.getAttribute("r"),10);
    const g={};
    row.querySelectorAll("c").forEach(c=>{
      const ref=c.getAttribute("r")||""; const col=colToNum(ref);
      const t=c.getAttribute("t"); let val="";
      const v=c.querySelector("v");
      if(t==="s"&&v)val=sst[parseInt(v.textContent,10)]||"";
      else if(t==="inlineStr"){const is=c.querySelector("is");val=is?is.textContent:"";}
      else if(v){
        val=v.textContent;
        // date column heuristic: col 4 numeric serial -> formatted
        if(col===4&&/^\d+(\.\d+)?$/.test(val)){const n=parseFloat(val);if(n>20000&&n<80000)val=excelDate(n);}
      }
      g[col]=val;
    });
    rowMap[r]=g;
  });
  // sanity: header row 6 must look like the WarU layout
  const h=rowMap[6]||{};
  if(!/Located at/i.test(h[2]||"")||!/P or C/i.test(h[7]||""))
    throw new Error("Column layout doesn't match the WarU matrix (checked row 6). The tool's column map needs updating.");
  const dataRows=[];
  const maxR=Math.max(...Object.keys(rowMap).map(Number));
  for(let r=7;r<=maxR;r++)if(rowMap[r])dataRows.push(rowMap[r]);
  // version date from row 2 col 6 if present
  let label="uploaded matrix";
  const ver=rowMap[2]&&rowMap[2][6];
  if(ver){
    const n=parseFloat(ver);
    label="WarU matrix — "+((!isNaN(n)&&n>20000&&n<80000)?excelDate(n):ver);
  }
  return {rows:processRows(dataRows),label};
}

async function loadMatrixFile(file){
  if(!file)return;
  const msg=document.getElementById("toolmsg");
  msg.textContent="Parsing "+file.name+"\u2026";
  try{
    if(typeof DecompressionStream==="undefined")throw new Error("This browser doesn't support built-in decompression (needs Edge/Chrome 80+ or Safari 16.4+).");
    const buf=await file.arrayBuffer();
    const {rows,label}=await parseXlsxMatrix(buf);
    if(rows.length<500)throw new Error("Only "+rows.length+" rows parsed — file doesn't look like the full matrix.");
    DATA=rows; MATRIX_LABEL=label+" (loaded from "+file.name+")";
    results=null;screened=null;for(const k in coNA)delete coNA[k];
    renderHeader();renderResults();
    msg.textContent="Loaded "+rows.length+" provisions/clauses \u2713 — regenerate your list.";
  }catch(e){
    msg.textContent="Could not load: "+e.message+" — still using "+MATRIX_LABEL+".";
  }
  document.getElementById("mfile").value="";
}

