/* ===== MODULE 03: state ===== */
const PURPOSES_NC=[["nsup","Supplies"],["nsvc","Services"],["rd","Research & Development"],["con","Construction"],["ae","Architect-Engineer"],["ddr","Dismantling / Demolition / Removal"],["lmv","Leasing of Motor Vehicles"],["commsvc","Communication Services"],["trn","Transportation"],["utl","Utility Services"]];
const PURPOSES_C=[["csup","Commercial Products (Supplies)"],["csvc","Commercial Services"]];
const REG_MAP={civ:["FAR"],dod:["FAR","DFARS","DOD CD"],dear:["FAR","DEAR"],va:["FAR","VAAR"],doi:["FAR","DIAR"],daf:["FAR","DFARS","DOD CD","DAFFARS"]};

function parseMoney(s){
  if(typeof s==="number")return s;
  const m=/^\s*\$?\s*([\d][\d,]*(?:\.\d+)?)\s*([kKmMbB])?\s*$/.exec(s||"");
  if(!m)return null;
  let v=parseFloat(m[1].replace(/,/g,""));
  if(m[2]){const u=m[2].toLowerCase();v*=u==="k"?1e3:u==="m"?1e6:1e9;}
  return isFinite(v)&&v>0?v:null;
}
function fmtMoney(n){return "$"+(n>=1e6?(n/1e6).toLocaleString(undefined,{maximumFractionDigits:2})+"M":n.toLocaleString());}
const state={rfo:null,agency:null,doctype:null,comm:null,purpose:null,cots:null,ctype:null,method:null,value:null,oconus:null};

function regLabel(reg){
  if(state.rfo==="no") return reg;
  if(reg==="FAR") return "RFO";
  if(reg==="DFARS") return "R-DFARS";
  return reg;
}

const QS=[
 {id:"rfo",q:"Is this acquisition under the RFO model deviations?",
  opts:[["yes","Yes — RFO / R-DFARS adopted"],["no","No — legacy 48 CFR"],["both","Unsure — show both, flagged"]],
  hint:"Per EO 14275 / OMB M-25-26. 'Yes' drops the provisions/clauses removed by the RFO and includes the new RFO provisions; citations display as RFO / R-DFARS. 'No' shows the pre-RFO set under legacy 48 CFR names."},
 {id:"agency",q:"Which regulation set governs this acquisition?",
  opts:[["civ","Civilian — RFO only"],["dod","DoD — RFO + R-DFARS + DoD CDs"],["dear","DOE — RFO + DEAR"],["va","VA — RFO + VAAR"],["doi","DOI — RFO + DIAR"],["daf","Air Force — RFO + R-DFARS + DAFFARS"]],
  hint:"Determines which supplements are pulled in alongside the RFO."},
 {id:"doctype",q:"What document is this list for?",
  opts:[["prime_sol","Prime — solicitation (provisions + clauses)"],["prime_awd","Prime — award / order (clauses only)"],["nsubk","Subcontract flowdown — noncommercial"],["csubk","Subcontract flowdown — commercial"]],
  hint:"Award/order documents carry contract clauses only — solicitation provisions are excluded. Flowdown lists are built from the matrix's subcontract columns and skip the prime-acquisition questions."},
 {id:"comm",q:"Commercial or noncommercial acquisition?",cond:()=>state.doctype&&state.doctype.startsWith("prime"),
  opts:[["C","Commercial (Part 12)"],["N","Noncommercial"]],
  hint:"Part 12 procedures limit which provisions/clauses may be used — see the RFO Part 12 model deviation text (legacy FAR 12.301)."},
 {id:"purpose",cond:()=>state.doctype&&state.doctype.startsWith("prime"),q:"What is being acquired?",opts:null,
  hint:"Pick the category that best matches the principal purpose of the contract."},
 {id:"cots",q:"Is the acquisition solely for COTS items?",
  opts:[["yes","Yes — COTS only"],["no","No"]],cond:()=>state.doctype&&state.doctype.startsWith("prime")&&state.purpose==="csup",
  hint:"Some clauses (e.g., 52.204-21) do not apply to acquisitions solely for COTS items."},
 {id:"ctype",cond:()=>state.doctype&&state.doctype.startsWith("prime"),q:"Contract type contemplated?",
  opts:[["fp","Fixed-Price"],["cr","Cost-Reimbursement"],["tm","T&M / Labor-Hour"]],
  hint:"For letter contracts / unpriced POs, choose the definitive contract type contemplated."},
 {id:"method",cond:()=>state.doctype&&state.doctype.startsWith("prime"),q:"Contracting method?",
  opts:[["sap","Simplified Acquisition Procedures"],["sld","Sealed Bidding"],["neg","Negotiation (Part 15)"]],
  hint:"SAP excludes micro-purchases."},
 {id:"value",cond:()=>state.doctype&&state.doctype.startsWith("prime"),q:"Estimated value?",money:true,opts:[],
  hint:"Enter the estimated total value, options included (e.g., 1,500,000 or 1.5M or 750K). At or below $350K filters items not authorized below the SAT; dollar triggers parsed from prescriptions (e.g., $2M TINA, $7.5M ethics) are compared against this exact figure."},
 {id:"oconus",cond:()=>state.doctype&&state.doctype.startsWith("prime"),q:"Any performance outside the United States?",
  opts:[["yes","Yes — OCONUS performance"],["no","No — U.S. only"]],
  hint:"Drives screening of clauses triggered by (or excluded by) foreign performance."}
];

const REF=[
 {id:"setaside",  q:"Small business set-aside or socioeconomic program award?", d:"8(a), HUBZone, SDVOSB, WOSB, total/partial set-aside", gate:null},
 {id:"tina",      q:"Certified cost or pricing data expected?", d:"Generally negotiated, noncommercial, > $2M, no exception", gate:null},
 {id:"idiq",      q:"Indefinite-delivery vehicle?", d:"IDIQ / requirements / task-or-delivery-order contract", gate:null},
 {id:"financing", q:"Contract financing contemplated?", d:"Progress payments, performance-based payments, advance payments", gate:null},
 {id:"evms",      q:"Major system acquisition / EVMS?", d:"Earned value management, major defense acquisition program", gate:null},
 {id:"ittelecom", q:"Information technology or telecom acquisition?", d:"IT systems, telecom services or equipment", gate:null},
 {id:"gfp",       q:"Government property to be furnished?", d:"GFP / Government-furnished material or equipment", gate:null},
 {id:"classified",q:"Access to classified information?", d:"Confidential / Secret / Top Secret, DD 254", gate:null},
 {id:"hazmat",    q:"Hazardous materials, ammunition, or explosives?", d:"", gate:["nsup","csup","con","ddr","rd","nsvc"]},
 {id:"domestic",  q:"Supplies or construction material delivered/used in the U.S.?", d:"Drives Buy American / Trade Agreements / Berry / specialty metals family", gate:["nsup","csup","con"]},
 {id:"personal",  q:"Personal services contract?", d:"", gate:["nsvc","csvc"]},
 {id:"uca",       q:"Letter contract / undefinitized contract action?", d:"Includes unpriced purchase orders", gate:null},
 {id:"cui",       q:"Will the contractor handle CUI / covered defense information?", d:"Controlled unclassified information — DFARS safeguarding, cyber incident reporting, CMMC. DoD note: the 252.204-7012 family is prescribed broadly; answer No only if your activity has affirmatively determined no CUI/CDI involvement (screened items remain auditable below)", gate:null},
 {id:"govsite",   q:"Performance on a Government installation or facility?", d:"Base/facility access, installation-specific requirements", gate:null},
 {id:"bonds",     q:"Bonds or other sureties required?", d:"Bid guarantees, performance and payment bonds", gate:null},
 {id:"warranty",  q:"Will the contract include a warranty?", d:"", gate:null},
 {id:"techdata",  q:"Delivery of technical data or computer software?", d:"Data rights / noncommercial software (DFARS 227 family)", gate:null},
 {id:"edunp",     q:"Award to an educational institution or nonprofit?", d:"", gate:null},
 {id:"sca",       q:"Services subject to Service Contract Labor Standards?", d:"SCLS/SCA-covered services; answer No for exempt (e.g., professional) services", gate:null},
 {id:"subkplan",  q:"Small business subcontracting plan required?", d:"Other-than-small offeror, > $750K ($1.5M construction), subcontracting possibilities", gate:null},
 {id:"fob",       q:"Delivery terms for supplies?", d:"Drives the 52.247 transportation family", gate:["nsup","csup"], opts:[["origin","FOB origin"],["dest","FOB destination"],["unk","Unsure / mixed"]]},
 {id:"firstart",  q:"First article testing required?", d:"", gate:["nsup","csup"]},
 {id:"sbir",      q:"SBIR / STTR program award?", d:"Small Business Innovation Research or Small Business Technology Transfer — any phase, including Phase III production/services. Drives the SBIR data-rights family (52.227-20 / 252.227-7993 / legacy -7018 set / STTR -7998/-7999)", gate:null}
];
let TAG_COUNTS=null;
function tagCountFor(refId){
  if(!TAG_COUNTS){
    TAG_COUNTS={};
    for(const c of DATA)for(const t of Object.keys(c.tags||{}))TAG_COUNTS[t]=(TAG_COUNTS[t]||0)+1;
  }
  if(refId==="fob")return (TAG_COUNTS.fobor||0)+(TAG_COUNTS.fobdest||0);
  return TAG_COUNTS[refId]||0;
}
const refState={};
REF.forEach(r=>refState[r.id]="unk");

function renderHeader(){
  document.getElementById("verbox").innerHTML="Loaded: "+esc(MATRIX_LABEL)+"<br>"+DATA.length+" provisions &amp; clauses";
  document.getElementById("matrixLabel").textContent=MATRIX_LABEL;
}

