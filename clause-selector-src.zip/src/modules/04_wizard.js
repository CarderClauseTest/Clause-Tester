/* ===== MODULE 04: wizard ===== */
function renderWizard(){
  const w=document.getElementById("wizard");w.innerHTML="";
  let qn=0;
  QS.forEach((s,i)=>{
    if(s.cond && !s.cond()){state[s.id]=state[s.id]??"na";return;}
    if(s.id==="cots"&&state[s.id]==="na")state[s.id]=null;
    if(s.id==="purpose"){if(state.comm===null||state.comm==="na")return;s.opts=state.comm==="C"?PURPOSES_C:PURPOSES_NC;}
    let prevOk=true;
    for(let j=0;j<i;j++){const pq=QS[j];if(pq.cond&&!pq.cond())continue;if(state[pq.id]===null){prevOk=false;break;}}
    if(!prevOk)return;
    qn++;
    const answered=s.money?(typeof state[s.id]==="number"):(state[s.id]!==null&&state[s.id]!=="na");
    const d=document.createElement("div");
    d.className="step"+(answered?" done collapsed":"");
    const lbl=answered?(s.money?fmtMoney(state[s.id]):(s.opts.find(o=>o[0]===state[s.id])||["",""])[1]):"";
    const bodyHtml=s.money
      ?`<div class="opts"><input type="text" id="qmoney" placeholder="e.g., 1,500,000 or 1.5M" style="border:1px solid var(--line2);padding:8px 12px;font:14px var(--mono);min-width:220px" value="${answered?fmtMoney(state[s.id]).replace('$',''):''}"><button class="opt" id="qmoneyset">Set</button></div>`
      :`<div class="opts">${s.opts.map(o=>`<button class="opt ${state[s.id]===o[0]?"sel":""}" data-v="${o[0]}">${o[1]}</button>`).join("")}</div>`;
    d.innerHTML=`<div class="step-h" tabindex="0" role="button" aria-expanded="${!answered}">
        <span class="qnum">Q${qn}</span><span class="q">${s.q}</span><span class="ans">${lbl}</span></div>
      <div class="step-b">${bodyHtml}
      <div class="hint">${s.hint}</div></div>`;
    d.querySelector(".step-h").addEventListener("click",()=>d.classList.toggle("collapsed"));
    d.querySelector(".step-h").addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();d.classList.toggle("collapsed");}});
    if(s.money){
      const inp=d.querySelector("#qmoney"), btn=d.querySelector("#qmoneyset");
      const commit=e=>{e&&e.stopPropagation();const v=parseMoney(inp.value);
        if(v===null){inp.style.borderColor="var(--req)";return;}
        state[s.id]=v;renderWizard();};
      btn.addEventListener("click",commit);
      inp.addEventListener("click",e=>e.stopPropagation());
      inp.addEventListener("keydown",e=>{if(e.key==="Enter")commit(e);});
    }else d.querySelectorAll(".opt").forEach(b=>b.addEventListener("click",e=>{
      e.stopPropagation();
      state[s.id]=b.dataset.v;
      if(s.id==="comm"){state.purpose=null;state.cots=null;}
      if(s.id==="purpose"&&state.purpose!=="csup")state.cots="na";
      renderWizard();
    }));
    w.appendChild(d);
  });
  const allDone=QS.every(s=>(s.cond&&!s.cond())||(s.money?typeof state[s.id]==="number":state[s.id]!==null));
  document.getElementById("runBtn").disabled=!allDone;
  document.getElementById("refpanel").style.display=allDone?"block":"none";
  if(allDone)renderRef();
}

