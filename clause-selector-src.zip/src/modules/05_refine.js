/* ===== MODULE 05: refine ===== */
function renderRef(){
  const g=document.getElementById("refgrid");g.innerHTML="";
  let shownN=0, answeredN=0;
  REF.forEach(r=>{
    if(r.gate && !r.gate.includes(state.purpose)) {refState[r.id]="unk"; return;}
    shownN++;
    const answered=refState[r.id]!=="unk";
    if(answered)answeredN++;
    const row=document.createElement("div");
    row.className="refrow"+(answered?" answered":"");
    const q=document.createElement("div");q.className="refq";
    const n=tagCountFor(r.id);
    q.innerHTML=`${r.q}${n?` <span class="refcount" title="Provisions/clauses in the matrix carrying this condition">${n}</span>`:""}${r.d?`<small>${r.d}</small>`:""}`;
    const lead=document.createElement("div");lead.className="leader";lead.setAttribute("aria-hidden","true");
    const t=document.createElement("div");t.className="tri";t.setAttribute("role","group");t.setAttribute("aria-label",r.q);
    (r.opts||[["yes","Yes"],["no","No"],["unk","Unsure"]]).forEach(([v,l])=>{
      const b=document.createElement("button");
      const cls=v==="unk"?"unk":v==="no"?"no":"yes";
      b.className=cls+(refState[r.id]===v?" sel":"");b.textContent=l;
      b.setAttribute("aria-pressed",refState[r.id]===v?"true":"false");
      b.onclick=()=>{refState[r.id]=v;dirty=true;renderRef();};
      t.appendChild(b);
    });
    row.appendChild(q);row.appendChild(lead);row.appendChild(t);
    g.appendChild(row);
  });
  const hd=document.getElementById("refcountline");
  if(hd)hd.textContent=answeredN+" of "+shownN+" answered \u00b7 unanswered conditions screen nothing";
}

