/* ===== MODULE 06: engine ===== */
let results=null, screened=null;
const reviewed={}; const coNotes={};
let autoScreenDeps=true;
const DEP_KW=/\b(includes?|contains?|containing|included)\b/gi;
const CITE_RE=/\b((?:52|252)\.\d{3}-\d{1,4})\b/g;
function mineDeps(c){
  const text=c.presc+" "+(c.notes||[]).join(" ");
  const pos=new Set(), neg=new Set(); let m; DEP_KW.lastIndex=0;
  while((m=DEP_KW.exec(text))){
    const negated=NEG_RE.test(sentenceBefore(text,m.index));
    const win=text.slice(m.index+m[0].length, m.index+m[0].length+130);
    let cm; CITE_RE.lastIndex=0;
    while((cm=CITE_RE.exec(win))){
      if(cm[1]===c.cite)continue;
      (negated?neg:pos).add(cm[1]);
    }
  }
  return {pos:[...pos],neg:[...neg]};
}
let filt={text:"",cls:"all",pc:"all",hideThr:false,fillOnly:false,byUcf:false};
const coNA={};
let contractNo="";
function ckey(c){return c.cite+"|"+(c.alt||"")+"|"+(c.dev||"")+"|"+c.reg+"|"+c.title;}

function run(noScroll){
  const regs=REG_MAP[state.agency];
  const valueAmt=state.value;
  const out=[], scr=[], res=[];
  for(const c of DATA){
    if(!regs.includes(c.reg)) continue;
    if(state.rfo==="yes" && c.rfo==="RFO X") continue;
    if(state.rfo==="no"  && c.rfo==="ADD")   continue;
    let cls, thrFlag=false;
    if(state.doctype==="nsubk"||state.doctype==="csubk"){
      const fCode=c[state.doctype]; if(!fCode) continue;
      cls=fCode==="R"?"R":fCode==="A"?"A":"O";
    }else{
      if(state.doctype==="prime_awd" && c.pc.startsWith("P")) continue;
      const pCode=c.p[state.purpose]; if(!pCode) continue;
      const tCode=c[state.ctype];     if(!tCode) continue;
      const mCode=c[state.method];    if(!mCode) continue;
      if(typeof valueAmt==="number" && valueAmt<=350000 && !c.le350) continue;
      if(state.cots==="yes" && c.cots_na) continue;
      const codes=[pCode,tCode,mCode]; if(typeof valueAmt==="number" && valueAmt<=350000) codes.push(c.le350);
      cls="O"; if(codes.includes("R")) cls="R"; else if(codes.includes("A")) cls="A";
      thrFlag = !!(c.thr && typeof valueAmt==="number" && valueAmt<=c.thr);
    }
    let keep=false, screenReasons=[];
    for(const [tag,pol] of Object.entries(c.tags||{})){
      const a=refAnswer(tag);
      if(a==="unk") continue;
      if((pol==="pos"&&a==="yes")||(pol==="neg"&&a==="no")) keep=true;
      if((pol==="pos"&&a==="no")||(pol==="neg"&&a==="yes"))
        screenReasons.push(`${COND_LABEL[tag]}: you answered ${pol==="pos"?"No":"Yes"}`);
    }
    const rec={...c,cls,thrFlag,deps:mineDeps(c)};
    rec.inMaster=masterSet.has(c.cite);
    if(!rec.inMaster && rec.cls!=="R" && screenReasons.length && !keep){rec.why=screenReasons.join(" \u00b7 ");(coRestore[ckey(rec)]?res:scr).push(rec);}
    else out.push(rec);
  }
  if(autoScreenDeps){
    for(let pass=0;pass<6;pass++){
      const activeCites=new Set([...out.filter(c=>!coNA[ckey(c)]).map(c=>c.cite),...res.map(c=>c.cite),...masterSet]);
      let moved=false;
      for(let i=out.length-1;i>=0;i--){
        const c=out[i]; if(c.cls==="R")continue;
        const d=c.deps||{pos:[],neg:[]};
        if(d.pos.length&&!d.pos.some(x=>activeCites.has(x))){
          c.why="companion: requires "+d.pos.join(" or ")+" \u2014 none in current list (excluded or marked N/A)";
          (coRestore[ckey(c)]?res:scr).push(c); out.splice(i,1); moved=true;
        }else if(d.neg.length&&d.neg.some(x=>activeCites.has(x))){
          const hit=d.neg.filter(x=>activeCites.has(x));
          c.why="companion: not used when "+hit.join(", ")+" is included";
          (coRestore[ckey(c)]?res:scr).push(c); out.splice(i,1); moved=true;
        }
      }
      if(!moved)break;
    }
  }
  const srt=(a,b)=>a.cite.localeCompare(b.cite,undefined,{numeric:true})||a.title.localeCompare(b.title);
  out.sort(srt); scr.sort(srt);
  res.sort(srt);
  results=out; screened=scr; restoredItems=res; masterItems=out.filter(c=>c.inMaster);
  syncMasterExtra();
  genTime=new Date(); dirty=true;
  renderResults();
  if(!noScroll)document.getElementById("out").scrollIntoView({behavior:"smooth"});
}
