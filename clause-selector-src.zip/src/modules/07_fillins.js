/* ===== MODULE 07: fillins ===== */
const fillValues={}; // ckey -> {idx: value} ('1' for checked boxes)
const BLANK_RE=/(_{3,})|(\[(?:insert|identify|contracting officer|to be inserted)[^\]]{0,200}\])|(\u25a1)/gi;
const INSTR_RE=/select|check\b|mark\b|complete/i;
function tokenizeFull(text,title){
  const toks=[]; let last=0; let m; BLANK_RE.lastIndex=0; let idx=0;
  const tprefix=(title||"").slice(0,18).toLowerCase();
  while((m=BLANK_RE.exec(text))){
    const pre=()=>{if(m.index>last)toks.push({t:"x",v:text.slice(last,m.index)});};
    if(m[1]){ // underscores — decorative if leading or immediately followed by the clause title
      const after=text.slice(m.index+m[0].length,m.index+m[0].length+40).replace(/^\s+/,"").toLowerCase();
      if(m.index===0||(tprefix&&after.startsWith(tprefix))){
        pre(); toks.push({t:"x",v:m[0]}); last=m.index+m[0].length; continue;
      }
      pre(); toks.push({t:"b",i:idx++,label:"fill in",orig:m[0]});
    }else if(m[2]){
      const label=m[2].slice(1,-1).trim();
      pre();
      if(INSTR_RE.test(label)) toks.push({t:"ins",v:m[2]});
      else toks.push({t:"b",i:idx++,label,orig:m[0]});
    }else{ // checkbox \u25a1
      // label: previous word + rest of line after the box
      const back=text.slice(Math.max(0,m.index-30),m.index);
      const pw=(back.match(/(\S+)\s*$/)||[])[1]||"";
      const rest=(text.slice(m.index+1).split(/\r?\n/)[0]||"").trim();
      const label=((pw?pw+" ":"")+(rest||"")).replace(/[\u25a1\u2612]/g,"").replace(/\s+/g," ").trim().slice(0,60)||"checkbox";
      pre(); toks.push({t:"cb",i:idx++,label});
    }
    last=m.index+m[0].length;
    if(m.index===BLANK_RE.lastIndex)BLANK_RE.lastIndex++;
  }
  if(last<text.length)toks.push({t:"x",v:text.slice(last)});
  return toks;
}
function fillSet(key,i,val,id){(fillValues[key]=fillValues[key]||{})[i]=val;dirty=true;if(id!==undefined)updateFillUI(key,id);}
function hasFillEntries(c){const fc=fillCount(c);return fc.tDone>0||fc.cbOn>0;}
function fillCount(c){
  const key=ckey(c), store=fillValues[key]||{};
  const toks=tokenizeFull(c.full||"",c.title);
  const tb=toks.filter(t=>t.t==="b"), cb=toks.filter(t=>t.t==="cb");
  const tDone=tb.filter(t=>(store[t.i]||"").trim()).length;
  const cbOn=cb.filter(t=>store[t.i]==="1").length;
  const complete=(tb.length>0&&tDone===tb.length)||(tb.length===0&&cb.length>0&&cbOn>0);
  return {tTotal:tb.length,tDone,cbTotal:cb.length,cbOn,complete};
}
function fillStatusText(fc){
  const bits=[];
  if(fc.tTotal)bits.push(`<span>${fc.tDone} of ${fc.tTotal} fill-in${fc.tTotal===1?"":"s"} completed</span>`);
  if(fc.cbTotal)bits.push(`<span>${fc.cbOn} of ${fc.cbTotal} box${fc.cbTotal===1?"":"es"} selected</span>`);
  return bits.join(" \u00b7 ")||"no entries detected";
}
function updateFillUI(key,id){
  const c=[...(results||[]),...restoredItems].find(x=>ckey(x)===key); if(!c)return;
  const fc=fillCount(c);
  const cnt=document.getElementById("fc"+id); if(cnt)cnt.innerHTML=fillStatusText(fc);
  const btn=document.getElementById("fb"+id);
  if(btn){btn.textContent=fc.complete?"fill-ins \u2713":"fill-ins";btn.classList.toggle("donefill",fc.complete);}
}
function fillPanelHTML(c,id){
  if(!c.full)return `<div class="fillpanel"><div class="fillbar">Full text not available in the matrix for this item — complete fill-ins from acquisition.gov.</div></div>`;
  const key=ckey(c), store=fillValues[key]||{};
  const toks=tokenizeFull(c.full,c.title);
  const kq=esc(key).replace(/'/g,"\\'");
  const body=toks.map(t=>{
    if(t.t==="x")return esc(t.v);
    if(t.t==="ins")return `<mark class="instr">${esc(t.v)}</mark>`;
    if(t.t==="cb"){
      const on=store[t.i]==="1";
      return `<input type="checkbox" ${on?"checked":""} title="${esc(t.label)}" aria-label="${esc(t.label)}" onchange="fillSet('${kq}',${t.i},this.checked?'1':'',\u0027${id}\u0027)">`;
    }
    const v=store[t.i]||"";
    const w=Math.min(420,Math.max(90,(t.label.length*7)));
    return `<input type="text" value="${esc(v)}" placeholder="${esc(t.label)}" title="${esc(t.label)}" style="width:${w}px" oninput="fillSet('${kq}',${t.i},this.value,'${id}')">`;
  }).join("");
  const fc=fillCount(c);
  return `<div class="fillpanel"><div class="fillbar">
      <span id="fc${id}">${fillStatusText(fc)}</span>
      <button onclick="copyCompleted('${kq}','${id}')">Copy completed text</button>
      <span id="cp${id}"></span>
      <span>Entries save with the session and print in the Fill-In Data appendix.</span>
    </div><div class="fulltext">${body}</div></div>`;
}
function copyCompleted(key,id){
  const c=[...(results||[]),...restoredItems].find(x=>ckey(x)===key); if(!c||!c.full)return;
  const store=fillValues[key]||{};
  const text=tokenizeFull(c.full,c.title).map(t=>{
    if(t.t==="x"||t.t==="ins")return t.v;
    if(t.t==="cb")return store[t.i]==="1"?"\u2612":"\u25a1";
    return (store[t.i]||"").trim()||t.orig;
  }).join("");
  const done=()=>{const el=document.getElementById("cp"+id);if(el){el.textContent="Copied \u2713";setTimeout(()=>el.textContent="",2000);}};
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(done).catch(()=>fallbackCopy(text,done));}
  else fallbackCopy(text,done);
}
function fallbackCopy(text,done){
  const ta=document.createElement("textarea");ta.value=text;document.body.appendChild(ta);ta.select();
  try{document.execCommand("copy");done();}catch(e){alert("Copy failed — select the text manually.");}
  document.body.removeChild(ta);
}

function rowHTML(c,id,mode){
  const key=ckey(c);
  const notes=(c.notes||[]).map(n=>`<div class="note">${esc(n)}</div>`).join("");
  const na=coNA[key];
  const kq=esc(key).replace(/'/g,"\\'");
  const btns = (mode==="main"&&c.inMaster)
    ? `<button class="exp" onclick="document.getElementById('r${id}').classList.toggle('open')">prescription</button>`
    : mode==="mst"
    ? `<button class="exp" onclick="document.getElementById('r${id}').classList.toggle('open')">prescription</button>
       ${c.fill?(()=>{const fc=fillCount(c);return `<button class="fillbtn${fc.complete?" donefill":""}" id="fb${id}" onclick="document.getElementById('r${id}').classList.toggle('fillopen')">${fc.complete?"fill-ins \u2713":"fill-ins"}</button>`;})():""}
       <button class="nabtn" onclick="removeFromParent('${esc(c.cite).replace(/'/g,"\\'")}')" title="Treat this cite as NOT incorporated in the parent contract \u2014 it returns to this order's own list">Remove from parent</button>`
    : mode==="scr"
    ? `<button class="exp" onclick="document.getElementById('r${id}').classList.toggle('open')">prescription</button>
       <button class="restore" onclick="restoreScreened('${kq}')" title="CO determines this item applies — return it to the list">Restore to list</button>`
    : mode==="res"
    ? `<button class="exp" onclick="document.getElementById('r${id}').classList.toggle('open')">prescription</button>
       ${c.fill?(()=>{const fc=fillCount(c);return `<button class="fillbtn${fc.complete?" donefill":""}" id="fb${id}" onclick="document.getElementById('r${id}').classList.toggle('fillopen')">${fc.complete?"fill-ins \u2713":"fill-ins"}</button>`;})():""}
       <button class="nabtn" onclick="unrestoreScreened('${kq}')" title="Send back to the screened section">Send back</button>`
    : mode==="na"
    ? `<button class="restore" onclick="restoreNA('${kq}')">Restore</button>`
    : `<button class="exp" onclick="document.getElementById('r${id}').classList.toggle('open')">prescription</button>
       ${c.fill&&mode==="main"?(()=>{const fc=fillCount(c);return `<button class="fillbtn${fc.complete?" donefill":""}" id="fb${id}" onclick="document.getElementById('r${id}').classList.toggle('fillopen')">${fc.complete?"fill-ins \u2713":"fill-ins"}</button>`;})():""}
       ${mode==="main"?`<button class="notebtn${coNotes[key]?" has":""}" onclick="editNote('${kq}','${id}')" title="Working note (saves with session)">note</button>
       <button class="revbtn${reviewed[key]?" sel":""}" id="rv${id}" onclick="toggleReviewed('${kq}','${id}')" title="Mark as reviewed">\u2713</button>`:""}
       <button class="nabtn" onclick="markNA('${kq}')" title="CO has reviewed and determined this item is not applicable">N/A \u2715</button>`;
  return `<div class="row${mode!=="main"||c.inMaster?" dim":""}${mode==="main"&&reviewed[key]?" revdone":""}" id="r${id}"${mode==="main"&&!c.inMaster?` data-main="1" data-key="${esc(key)}"`:""}>
    <span class="cite">${esc(c.cite)}</span>
    <span class="ttl">${esc(c.title)} <span class="stamp s-${c.cls}">${c.cls}</span>${badges(c)}${mode==="na"?`<span class="badge b-na">CO N/A</span>`:""}${mode==="mst"?`<span class="badge b-mst">Parent</span>`:""}${mode==="mst"&&c.fill&&hasFillEntries(c)?`<span class="badge b-add" title="Contracting Officer entries present \u2014 this item is set out in the full-text attachment">\u2192 full text</span>`:""}${mode==="main"&&c.inMaster?`<span class="badge b-mst" title="Already incorporated in the parent contract — shown for context; omitted from this order's printed parts">In ${esc(masterNo||"parent IDIQ/BPA")}</span>`:""}${mode==="res"?`<span class="badge b-add">Restored by CO</span>`:""}</span>
    <span class="rowbtns">${btns}</span>
    ${mode==="scr"?`<span class="scrnote">Screened — ${esc(c.why)}</span>`:""}
    ${mode==="na"&&na&&na.reason?`<span class="nanote">CO note: ${esc(na.reason)}</span>`:""}
    ${mode==="main"&&coNotes[key]?`<span class="wnote">${esc(coNotes[key])}</span>`:""}
    <span class="meta"><span class="tag">${c.pc.startsWith("P")?"Provision":"Clause"}</span><span class="tag">${esc(regLabel(c.reg))}</span>${c.ucf?`<span class="tag">UCF ${esc(c.ucf)}</span>`:""}${c.date?`<span class="tag">${esc(c.date)}</span>`:""}${c.presc_at?`<span class="tag">Prescribed: ${esc(c.presc_at)}</span>`:""}${c.alt?`<span class="tag">Alt ${esc(c.alt)}</span>`:""}</span>
    <div class="presc">${esc(c.presc)||"<i>No prescription text in matrix.</i>"}</div>
    ${notes}
    ${c.fill&&(mode==="main"||mode==="res"||mode==="mst")?fillPanelHTML(c,id):""}
  </div>`;
}

function renderResults(){
  _allOpen=false;
  const o=document.getElementById("out");
  if(!results){o.innerHTML="";return;}
  const naItems=results.filter(c=>coNA[ckey(c)]);
  const activeAll=results.filter(c=>!coNA[ckey(c)]);
  const active=activeAll.filter(c=>!c.inMaster);
  const shown=activeAll.filter(c=>{
    if(filt.cls!=="all"&&c.cls!==filt.cls)return false;
    if(filt.pc!=="all"&&!c.pc.startsWith(filt.pc))return false;
    if(filt.hideThr&&c.thrFlag)return false;
    if(filt.fillOnly&&!c.fill)return false;
    if(filt.text){const t=filt.text.toLowerCase();
      if(!c.cite.toLowerCase().includes(t)&&!c.title.toLowerCase().includes(t))return false;}
    return true;
  });
  // companion-dependency check against the active list
  const activeCites=new Set([...activeAll.map(c=>c.cite),...restoredItems.map(c=>c.cite),...masterSet]);
  active.forEach(c=>{
    const d=c.deps||{pos:[],neg:[]};
    c.depMissing=(d.pos.length&&!d.pos.some(x=>activeCites.has(x)))?d.pos:[];
    c.depConflict=(d.neg||[]).filter(x=>activeCites.has(x));
  });
  const depIssues=active.filter(c=>c.depMissing.length||c.depConflict.length);
  const revDone=active.filter(c=>reviewed[ckey(c)]).length;
  const nR=active.filter(c=>c.cls==="R").length,nA=active.filter(c=>c.cls==="A").length,nO=active.filter(c=>c.cls==="O").length;
  const nThr=active.filter(c=>c.thrFlag).length;
  const nFill=active.filter(c=>c.fill).length;
  let html=`<div class="summary"><b>${active.length}</b> in list${genTime?` <span style="color:var(--ink2)">· generated ${genTime.toLocaleTimeString()}</span>`:""} — <span class="stamp s-R">R ${nR}</span> <span class="stamp s-A">A ${nA}</span> <span class="stamp s-O">O ${nO}</span>${nThr?` — <span class="badge b-thr">${nThr} below stated threshold?</span>`:""}${nFill?` — <span class="badge b-fill">${nFill} need fill-ins</span>`:""}${screened.length?` — <span class="badge b-rm">${screened.length} screened (audit below)</span>`:""}${naItems.length?` — <span class="badge b-na">${naItems.length} CO N/A</span>`:""}${masterItems.length?` — <span class="badge b-mst">${masterItems.length+Object.keys(masterExtra).length} in parent</span>`:""}<br>
  <span class="progress">Review progress: <span class="pbar"><i id="revbar" style="width:${active.length?Math.round(100*revDone/active.length):0}%"></i></span> <span id="revcount">${revDone} / ${active.length} reviewed</span></span>
  &nbsp;<button class="fchip" onclick="jumpUnreviewed()">Jump to first unreviewed</button></div>
  ${depIssues.length?`<div class="warnpanel"><b>⚠ Companion check — ${depIssues.length} item${depIssues.length>1?"s":""} with unresolved companion conditions (kept in list)</b>${depIssues.map(c=>`${esc(c.cite)} ${esc(c.title.slice(0,60))} — ${c.depMissing.length?`needs ${c.depMissing.map(esc).join(" or ")}`:``}${c.depConflict.length?` conflicts with ${c.depConflict.map(esc).join(", ")} in list`:``}`).join("<br>")}</div>`:""}
  <div class="searchbar">
    <input type="search" placeholder="Filter by cite or title\u2026" value="${esc(filt.text)}" oninput="filt.text=this.value;renderResults()">
    ${[["all",`All (${active.length})`],["R",`Required (${nR})`],["A",`When applicable (${nA})`],["O",`Optional (${nO})`]].map(f=>
      `<button class="fchip ${filt.cls===f[0]?"sel":""}" onclick="filt.cls='${f[0]}';renderResults()">${f[1]}</button>`).join("")}
    ${[["all","P + C"],["P",`Provisions (${active.filter(c=>c.pc.startsWith("P")).length})`],["C",`Clauses (${active.filter(c=>c.pc.startsWith("C")).length})`]].map(f=>
      `<button class="fchip ${filt.pc===f[0]?"sel":""}" onclick="filt.pc='${f[0]}';renderResults()">${f[1]}</button>`).join("")}
    <button class="fchip ${filt.hideThr?"sel":""}" onclick="filt.hideThr=!filt.hideThr;renderResults()">Hide threshold-flagged</button>
    <button class="fchip ${filt.fillOnly?"sel":""}" onclick="filt.fillOnly=!filt.fillOnly;renderResults()">Fill-ins only (${nFill})</button>
    <button class="fchip" onclick="toggleAllPresc(this)">Expand prescriptions</button>
    <button class="fchip ${filt.byUcf?"sel":""}" onclick="filt.byUcf=!filt.byUcf;renderResults()">Group by UCF section</button>
    <button class="fchip" onclick="copySection('I')">Copy Sec I</button>
    <button class="fchip" onclick="copySection('K')">Copy Sec K</button>
    <button class="fchip" onclick="copySection('L')">Copy Sec L</button>
    <button class="fchip ${showVal?"sel":""}" onclick="showVal=!showVal;renderResults()">Validate against known list</button>
    <button class="fchip ${showMaster?"sel":""}" onclick="showMaster=!showMaster;renderResults()">Order off IDIQ / BPA</button>
    <input type="text" id="kno" placeholder="Solicitation / Contract No. (prints on attachment)" style="min-width:260px" value="${esc(contractNo)}" oninput="contractNo=this.value">
    <button class="ghost" onclick="exportXLS()">Export records (.xls)</button>
    <button class="ghost" onclick="exportCSV()">Export CSV</button>
    <button class="ghost" onclick="printAttachment()">Print clause IBR list</button>
    <button class="ghost" onclick="printFullText()">Print full text + fill-ins</button>
    <button class="ghost" onclick="printCOLog()">Print CO log</button>
  </div>
  ${showMaster?`<div class="valpanel"><h3>Ordering off an IDIQ / BPA — parent contract clauses</h3>
    <p style="font:12.5px var(--sans);color:var(--ink2);margin-bottom:8px">Paste any text containing the citations already incorporated in the parent contract or BPA (its Section I, a CSV, an email). Matching items are omitted from this order's list, the printed attachments, and the section copy blocks — but they still count as present for companion checks, so order-level clauses that depend on them stay in. Matching is at the cite level (Alternates not distinguished).</p>
    <textarea placeholder="Paste in any format — citations are detected automatically. Example:&#10;52.212-4   Contract Terms and Conditions—Commercial Products and Commercial Services   (NOV 2023)&#10;52.216-18, Ordering (AUG 2020); 52.216-19; 52.217-9&#10;252.204-7012 Safeguarding Covered Defense Information&#10;Per our Section I dated 12 MAR 2024, the order incorporates 52.232-40…" oninput="masterText=this.value">${esc(masterText)}</textarea>
    <div style="margin-top:8px;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
      <input type="text" placeholder="Parent contract / BPA No. (prints on the attachment)" style="border:1px solid var(--line2);padding:8px 12px;font:13px var(--mono);min-width:300px" value="${esc(masterNo)}" oninput="masterNo=this.value">
      <button class="ghost" onclick="applyMaster()">Apply</button>
      <button class="ghost" onclick="clearMaster()">Clear</button>
      <span style="font:12px var(--mono);color:var(--ink2)">${masterSet.size?masterSet.size+" cites applied":""}</span>
    </div>
  </div>`:""}
  ${showVal?`<div class="valpanel"><h3>Validation — compare against a known-good list</h3>
    <p style="font:12.5px var(--sans);color:var(--ink2);margin-bottom:8px">Paste any text containing clause citations from a completed acquisition (a Section I listing, a CSV, an email). Citations are extracted automatically; comparison is at the cite level (Alternates not distinguished). The tool reports what matched, what it lacks (with the gate or determination responsible), and what it has that the known list doesn't.</p>
    <textarea placeholder="Paste in any format — citations are detected automatically. Example:&#10;52.204-7   System for Award Management   (NOV 2024)&#10;52.212-1; 52.212-3 Alt I; 252.225-7001&#10;From the award email: …also includes 52.219-8 and 52.222-50…" oninput="valText=this.value">${esc(valText)}</textarea>
    <div style="margin-top:8px;display:flex;gap:10px;flex-wrap:wrap">
      <button class="ghost" onclick="runValidation()">Compare</button>
      ${valReport&&!valReport.empty?`<button class="ghost" onclick="copyValReport()">Copy report</button>`:""}
    </div>
    ${valReport?(valReport.empty?`<div class="vsum v-miss">No clause citations found in the pasted text.</div>`:`
      <div class="vsum">Matched <span class="v-ok">${valReport.matched.length}</span> · Missing from tool <span class="v-miss">${valReport.missing.length}</span> · Extra in tool <span class="v-extra">${valReport.extra.length}</span> · of ${valReport.total} pasted cites</div>
      ${valReport.missing.length?`<div class="vsum v-miss" style="margin-top:8px">Missing from tool</div>`+valReport.missing.map(([c,w])=>`<div class="vrow"><b>${esc(c)}</b> — ${esc(w)}</div>`).join(""):""}
      ${valReport.extra.length?`<div class="vsum v-extra" style="margin-top:8px">Extra in tool</div>`+valReport.extra.map(c=>`<div class="vrow"><b>${esc(c.cite)}</b> [${c.cls}] ${esc(c.title.slice(0,70))}</div>`).join(""):""}
    `):""}
  </div>`:""}
  <div class="legend">R — required · A — required when applicable: read the prescription · O — optional · Fill-in — clause text contains blanks the CO must complete · N/A \u2715 — CO has reviewed and determined the item does not apply · R-DFARS CD — use the class-deviated text, not legacy 48 CFR</div>`;

  if(filt.byUcf){
    const order=["B","C","D","E","F","G","H","I","J","K","L","M",""];
    const seen=new Set(shown.map(ucfOf));
    let gi=0;
    for(const u of order){
      if(!seen.has(u))continue;
      const items=shown.filter(c=>ucfOf(c)===u);
      const label=u?("Section "+u+" — "+(UCF_LABELS[u]||"")):"No UCF section assigned";
      html+=`<div class="grp"><h2>${label}</h2><span class="ct">${items.length} item${items.length>1?"s":""}${u?` · <button class="fchip" onclick="copySection('${u}')">Copy block</button>`:""}</span></div>`;
      html+=items.map((c,i)=>rowHTML(c,"U"+(gi)+"_"+i,"main")).join("");
      gi++;
    }
  }else for(const grp of [["R","Required"],["A","Required when applicable"],["O","Optional"]]){
    const items=shown.filter(c=>c.cls===grp[0]);
    if(!items.length) continue;
    html+=`<div class="grp"><h2>${grp[1]}</h2><span class="ct">${items.length} item${items.length>1?"s":""}</span></div>`;
    html+=items.map((c,i)=>rowHTML(c,grp[0]+i,"main")).join("");
  }
  if(naItems.length){
    html+=`<div class="grp na"><h2>CO determinations — not applicable</h2><span class="ct">${naItems.length} items</span></div>
    <p style="font-size:12.5px;color:var(--ink2);margin:6px 0 10px">Reviewed and determined not applicable for this acquisition. These stay visible for the record, export to CSV with the CO's note, and are omitted from the printed attachment. Use Restore to return one to the list.</p>`;
    html+=naItems.map((c,i)=>rowHTML(c,"N"+i,"na")).join("");
  }
  if(restoredItems.length){
    html+=`<div class="grp"><h2 style="color:var(--opt)">Restored by CO determination</h2><span class="ct">${restoredItems.length} item${restoredItems.length>1?"s":""}</span></div>
    <p style="font-size:12.5px;color:var(--ink2);margin:6px 0 10px">Screened by refinement or companion logic, then returned to the list by the Contracting Officer. These print and copy like any other item and count as present for companion checks.</p>`;
    html+=restoredItems.map((c,i)=>rowHTML(c,"RS"+i,"res")).join("");
  }
  if(masterItems.length||Object.keys(masterExtra).length||Object.keys(masterRemoved).length){
    html+=`<div class="grp mst"><h2>Incorporated in parent ${masterNo?esc(masterNo):"IDIQ / BPA"} — not re-listed</h2><span class="ct">${masterItems.length} items</span></div>
    <p style="font-size:12.5px;color:var(--ink2);margin:6px 0 10px">Already incorporated in the parent contract — these also appear greyed in their classification groups above for context. Omitted from this order's Parts 1–2 and copy blocks; printed in their own part on the attachment. They satisfy companion conditions for order-level clauses. Verify the parent's version/date governs.</p>`;
    html+=masterItems.map((c,i)=>rowHTML(c,"M"+i,"mst")).join("");
    const pxs=Object.keys(masterExtra).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
    if(pxs.length){
      html+=`<p style="font:600 12.5px var(--sans);color:var(--ink2);margin:12px 0 6px">Parent-only items — incorporated in the parent but not generated by this order's profile. Confirm or complete title and date from the parent contract; check fill-in if the clause contains material the specialist must complete.</p>`;
      html+=pxs.map(cite=>{const m=masterExtra[cite];const cq=cite.replace(/'/g,"\\'");
        return `<div class="row dim" style="grid-template-columns:130px 1fr">
          <span class="cite">${esc(cite)}</span>
          <span style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            <input type="text" placeholder="Title (from parent contract)" value="${esc(m.title)}" style="border:1px solid var(--line2);padding:5px 9px;font:12.5px var(--mono);flex:1;min-width:240px" oninput="masterExtra['${cq}'].title=this.value;dirty=true">
            <input type="text" placeholder="Date" value="${esc(m.date)}" style="border:1px solid var(--line2);padding:5px 9px;font:12.5px var(--mono);width:84px" oninput="masterExtra['${cq}'].date=this.value;dirty=true">
            <label style="font:600 11.5px var(--mono);cursor:pointer;white-space:nowrap"><input type="checkbox" ${m.fill?"checked":""} style="accent-color:#9d174d;vertical-align:-2px" onchange="masterExtra['${cq}'].fill=this.checked;dirty=true"> fill-in</label>
            ${m.rfoRemoved?`<span class="badge b-rm" title="Removed by the RFO for new actions — applies to this order through the parent contract">Removed by RFO \u2014 applies via parent</span>`:""}
            ${!m.inMatrix?`<span class="badge b-tag" title="Cite not found in the loaded matrix — complete details from the parent contract">Not in matrix</span>`:""}
            <button class="nabtn" onclick="removeFromParent('${cq}')" title="Remove this cite from the parent list">Remove</button>
          </span></div>`;}).join("");
    }
    const rmv=Object.keys(masterRemoved).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
    if(rmv.length){
      html+=`<p style="font:12px var(--mono);color:var(--ink3);margin:10px 0 0">Removed from parent by specialist: ${rmv.map(c=>{const cq2=c.replace(/'/g,"\\'");return `<span style="text-decoration:line-through">${esc(c)}</span> <button style="border:none;background:none;color:#1d4ed8;cursor:pointer;font:inherit;text-decoration:underline;padding:0" onclick="undoParentRemoval('${cq2}')">undo</button>`;}).join(" \u00b7 ")}</p>`;
    }
  }
  if(screened.length){
    html+=`<div class="grp scr"><h2>Screened out by refinement answers — audit</h2><span class="ct">${screened.length} items</span></div>
    <p style="font-size:12.5px;color:var(--ink2);margin:6px 0 10px">Removed because every condition that triggers them was answered definitively. Skim before discarding — keyword screening can misread a prescription. Required (R) items are never screened.</p>`;
    html+=screened.map((c,i)=>rowHTML(c,"S"+i,"scr")).join("");
  }
  o.innerHTML=html;
}

