/* ===== MODULE 08: rows ===== */
function badges(c){
  let h="";
  if(state.rfo==="both" && c.rfo==="RFO X") h+=`<span class="badge b-rm" title="Removed by the RFO \u2014 applies only under legacy 48 CFR posture">Removed by RFO</span>`;
  if(c.rfo==="ADD") h+=`<span class="badge b-add" title="Added by the RFO model deviations">RFO new</span>`;
  if(c.rfo==="DFARS CD") h+=`<span class="badge b-cd" title="Subject to an R-DFARS class deviation \u2014 use the deviated text, not legacy 48 CFR">R-DFARS CD</span>`;
  if(c.dev) h+=`<span class="badge b-cd">Deviation ${esc(c.dev)}</span>`;
  if(c.thrFlag) h+=`<span class="badge b-thr" title="Prescription states a dollar trigger at or above your estimated value \u2014 verify applicability">Threshold? $${fmt(c.thr)}</span>`;
  if(c.fill) h+=`<span class="badge b-fill" title="Clause text contains blanks or selections the CO must complete \u2014 use the fill-ins button">Fill-in</span>`;
  if(/^n/i.test(c.ibr||"")) h+=`<span class="badge b-ft" title="Incorporation by reference not authorized \u2014 set out in full text (included in the full-text attachment)">Full text req\u2019d</span>`;
  if(c.nsubk||c.csubk) h+=`<span class="badge b-flow" title="Matrix marks this for subcontract flowdown">Flowdown</span>`;
  if(state.oconus==="yes"&&c.oconus) h+=`<span class="badge b-oco">OCONUS</span>`;
  if(c.iap==="IAP") h+=`<span class="badge b-add">IAP 12.205</span>`;
  if(c.depMissing&&c.depMissing.length) h+=`<span class="badge b-dep">Needs ${c.depMissing.map(esc).join(" or ")}</span>`;
  if(c.depConflict&&c.depConflict.length) h+=`<span class="badge b-dep">Conflicts: ${c.depConflict.map(esc).join(", ")}</span>`;
  if(coNotes[ckey(c)]) h+=`<span class="badge b-note">Note</span>`;
  for(const [tag,pol] of Object.entries(c.tags||{})){
    if(refAnswer(tag)==="yes"&&pol==="pos") h+=`<span class="badge b-tag">${COND_LABEL[tag]}</span>`;
  }
  return h;
}
function fmt(n){return n>=1e6?(n/1e6)+"M":n.toLocaleString()}

