/* ===== MODULE 09: print ===== */
const SUPP_ORDER=["DEAR","VAAR","DIAR","DAFFARS","AFARS","NMCARS","DLAD"];
function regBucket(c){
  if(c.reg==="FAR")   return (c.dev||c.rfo==="ADD")?1:0;
  if(c.reg==="DFARS") return (c.dev||c.rfo==="DFARS CD")?3:2;
  if(c.reg==="DOD CD")return 4;
  const i=SUPP_ORDER.indexOf(c.reg);
  return 5+(i<0?SUPP_ORDER.length:i);
}
function bucketLabel(b){
  const far=regLabel("FAR"), df=regLabel("DFARS");
  if(b===0)return far;
  if(b===1)return far+" Deviations";
  if(b===2)return df;
  if(b===3)return df+" Deviations";
  if(b===4)return "Class Deviations (DoD CD)";
  return "Agency Supplement \u2014 "+(SUPP_ORDER[b-5]||"Other");
}
function printSort(a,b){
  const pa=a.pc.startsWith("P")?0:1, pb=b.pc.startsWith("P")?0:1;
  if(pa!==pb)return pa-pb;
  const ba=regBucket(a), bb=regBucket(b);
  if(ba!==bb)return ba-bb;
  return a.cite.localeCompare(b.cite,undefined,{numeric:true})||(a.alt||"").localeCompare(b.alt||"");
}
const FB_S="\u0001", FB_E="\u0002";
function printAttachment(){
  if(!results){alert("Generate a clause list first.");return;}
  const ibrNo=c=>/^n/i.test(c.ibr||"");
  const allActive=[...results.filter(c=>!coNA[ckey(c)]&&!c.inMaster),...restoredItems];
  const orderItems=allActive.filter(c=>!c.fill&&!ibrNo(c));
  const ftCount=allActive.length-orderItems.length;
  const mstRows=results.filter(c=>!coNA[ckey(c)]&&c.inMaster).sort(printSort);
  const today=new Date().toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"});
  let h=`<div class="pd-head"><h1>Provisions and Clauses Incorporated by Reference</h1>
    <div class="pd-sub">Incorporated pursuant to the Revolutionary FAR Overhaul (RFO)${state.agency==="dod"||state.agency==="daf"?" and R-DFARS":""} and applicable agency supplements</div></div>
  <div class="pd-id"><span><b>Solicitation / Contract No.:</b> ${contractNo?esc(contractNo):"_______________________"}</span><span><b>Date prepared:</b> ${today}</span></div>
  <div class="pd-basis"><b>Acquisition profile:</b> ${esc(profileLine())} &nbsp;\u2014&nbsp; <b>Source matrix:</b> ${esc(MATRIX_LABEL)}${ftCount?` &nbsp;\u2014&nbsp; <b>Note:</b> ${ftCount} item${ftCount>1?"s":""} containing fill-in material or not authorized for incorporation by reference ${ftCount>1?"are":"is"} set out in the companion attachment, Provisions and Clauses Incorporated in Full Text, and ${ftCount>1?"are":"is"} not listed here.`:""}</div>`;
  const tblRow=c=>`<tr><td class="pd-no">${esc(c.cite)}${c.alt?` Alt ${esc(c.alt)}`:""}${c.dev?` (Dev ${esc(c.dev)})`:""}</td><td>${esc(c.title)}</td><td class="pd-dt">${esc(c.date)}</td><td class="pd-uc">${esc(c.ucf)}</td></tr>`;
  const tblOpen=`<table><thead><tr><th style="width:124pt">Number</th><th>Title</th><th style="width:58pt">Date</th><th style="width:30pt">UCF</th></tr></thead><tbody>`;
  const bucketTables=items=>{
    let s="",lastB=-1,open=false;
    for(const c of items){
      const b=regBucket(c);
      if(b!==lastB){ if(open)s+=`</tbody></table>`; s+=`<h3 class="pd-sub2">${esc(bucketLabel(b))}</h3>`+tblOpen; open=true; lastB=b; }
      s+=tblRow(c);
    }
    if(open)s+=`</tbody></table>`;
    return s;
  };
  const sorted=[...orderItems].sort(printSort);
  for(const [pcKey,partName] of [["P","Solicitation Provisions"],["C","Contract Clauses"]]){
    const part=sorted.filter(c=>c.pc.startsWith(pcKey));
    if(!part.length)continue;
    h+=`<h2>${partName} (${part.length})</h2>`+bucketTables(part);
  }
  if(mstRows.length||Object.keys(masterExtra).length){
    h+=`<h2>Incorporated in Parent ${masterNo?esc(masterNo):"IDIQ / BPA"} (${mstRows.length+Object.keys(masterExtra).length})</h2>
    <p style="font-size:8.5pt;margin:0 0 4pt">The following provisions and clauses are incorporated in the parent contract and apply to this order through it; they are not re-incorporated by this document. Items marked \u2020 were removed by the RFO for new actions and apply via the parent; items marked * contain fill-in material to be completed under the parent contract\u2019s terms.</p>`;
    const pMov=mstRows.filter(c=>c.fill&&hasFillEntries(c));
    const pKeep=mstRows.filter(c=>!(c.fill&&hasFillEntries(c)));
    if(pKeep.length)h+=bucketTables(pKeep);
    const pxs=Object.keys(masterExtra).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
    if(pxs.length){
      h+=`<h3 class="pd-sub2">Parent-only items</h3>`+tblOpen;
      for(const cite of pxs){const x=masterExtra[cite];
        h+=`<tr><td class="pd-no">${esc(cite)}${x.rfoRemoved?" \u2020":""}${x.fill?" *":""}</td><td>${x.title?esc(x.title):'<span class="pd-pend">________________________________ [title]</span>'}</td><td class="pd-dt">${x.date?esc(x.date):'<span class="pd-pend">________ [date]</span>'}</td><td class="pd-uc"></td></tr>`;}
      h+=`</tbody></table>`;
    }
    if(pMov.length)h+=`<p style="font-size:8.5pt;margin:4pt 0 0"><b>${pMov.length}</b> parent item${pMov.length>1?"s":""} with Contracting Officer entries ${pMov.length>1?"are":"is"} set out in the companion attachment, Provisions and Clauses Incorporated in Full Text, and not listed here: ${pMov.map(c=>esc(c.cite)).join("; ")}.</p>`;
  }
  h+=`<div class="pd-note">UCF = Uniform Contract Format section. Items containing fill-in material or for which incorporation by reference is not authorized are set out with complete language in the companion attachment, Provisions and Clauses Incorporated in Full Text. Full text of each provision and clause is available at acquisition.gov. Provisions and clauses identified to a class deviation are incorporated as deviated. Items determined not applicable by the Contracting Officer are excluded from this attachment and documented separately in the contract file.</div>
  <div class="pd-sig"><div>Contracting Officer / Specialist</div><div>Date</div></div>`;
  document.getElementById("printdoc").innerHTML=h;
  window.print();
}
function buildSubstitutedFull(c){
  const store=fillValues[ckey(c)]||{};
  const marked=tokenizeFull(c.full,c.title).map(t=>{
    if(t.t==="x"||t.t==="ins")return t.v;
    if(t.t==="cb")return FB_S+(store[t.i]==="1"?"\u2612":"\u25a1")+FB_E;
    const v=(store[t.i]||"").trim();
    return FB_S+(v||"____________ ["+t.label+"]")+FB_E;
  }).join("");
  return esc(marked).split(FB_S).join('<span class="pd-ins">').split(FB_E).join("</span>");
}
function printFullText(){
  if(!results){alert("Generate a clause list first.");return;}
  const active=[...results.filter(c=>!coNA[ckey(c)]&&!c.inMaster),...restoredItems];
  const items=active.filter(c=>c.fill||/^n/i.test(c.ibr||"")).sort(printSort);
  const pmv=(results||[]).filter(c=>c.inMaster&&!coNA[ckey(c)]&&c.fill&&hasFillEntries(c)).sort(printSort);
  const ftTotal=items.length+pmv.length+Object.keys(masterExtra).filter(k=>masterExtra[k].fill).length;
  if(!items.length){alert("No fill-in or full-text-required items in the current list.");return;}
  const today=new Date().toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"});
  let h=`<div class="pd-head"><h1>Provisions and Clauses Incorporated in Full Text</h1>
    <div class="pd-sub">Companion to the clause listing — items containing Contracting Officer fill-in material or for which incorporation by reference is not authorized</div></div>
  <div class="pd-id"><span><b>Solicitation / Contract No.:</b> ${contractNo?esc(contractNo):"_______________________"}</span><span><b>Date prepared:</b> ${today}</span></div>
  <div class="pd-basis"><b>Source matrix:</b> ${esc(MATRIX_LABEL)} \u2014 ${ftTotal} item${ftTotal>1?"s":""}.${masterItems.length?` Items incorporated in parent ${masterNo?esc(masterNo):"contract"} are not repeated.`:""} Contracting Officer entries and selections appear in <span class="pd-ins">bold underline</span>; material not yet completed appears as a labeled blank.</div>`;
  for(const c of items){
    h+=`<div class="pd-ft"><h3>${esc(c.cite)}${c.alt?` Alt ${esc(c.alt)}`:""} \u2014 ${esc(c.title)} (${esc(c.date)})</h3>`;
    if(c.trunc)h+=`<div class="pd-tw">\u26a0 Text truncated at the source (matrix cell limit) \u2014 verify the complete clause at acquisition.gov before release.</div>`;
    if(!c.full)h+=`<div class="pd-ftx pd-pend">Full text not carried in the matrix \u2014 set out this ${c.pc.startsWith("P")?"provision":"clause"} from acquisition.gov.</div>`;
    else h+=`<div class="pd-ftx">${buildSubstitutedFull(c)}</div>`;
    h+=`</div>`;
  }
  for(const c of pmv){
    h+=`<div class="pd-ft"><h3>${esc(c.cite)}${c.alt?` Alt ${esc(c.alt)}`:""} \u2014 ${esc(c.title)} (${esc(c.date)}) \u2014 incorporated via parent ${masterNo?esc(masterNo):"contract"}; set out with Contracting Officer entries</h3>`;
    if(c.full)h+=`<div class="pd-ftx">${buildSubstitutedFull(c)}</div>`;
    else h+=`<div class="pd-ftx pd-pend">Full text not carried in the loaded matrix \u2014 set out this item from the parent contract\u2019s terms with the entries recorded on screen.</div>`;
    h+=`</div>`;}
  const pfx=Object.keys(masterExtra).filter(k=>masterExtra[k].fill).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
  for(const cite of pfx){const x=masterExtra[cite];
    const row=DATA.find(c=>c.cite===cite&&c.full)||null;
    h+=`<div class="pd-ft"><h3>${esc(cite)} \u2014 ${x.title?esc(x.title):'<span class="pd-pend">[title from parent contract]</span>'}${x.date?` (${esc(x.date)})`:""} \u2014 incorporated via parent ${masterNo?esc(masterNo):"contract"}</h3>`;
    if(row)h+=`<div class="pd-ftx">${esc(row.full)}</div>`;
    else h+=`<div class="pd-ftx pd-pend">Text not carried in the loaded matrix \u2014 set out and complete this item from the parent contract\u2019s incorporated terms.</div>`;
    h+=`</div>`;}
  h+=`<div class="pd-note">Items marked with a truncation warning must be completed from the authoritative text. This attachment is generated from the loaded provision &amp; clause matrix and the Contracting Officer's entries recorded in the selector tool.</div>
  <div class="pd-sig"><div>Contracting Officer / Specialist</div><div>Date</div></div>`;
  document.getElementById("printdoc").innerHTML=h;
  window.print();
}

/* ===== CO determinations & changes log (audit trail for the file) ===== */
function printCOLog(){
  const pool=[...(results||[]),...(screened||[]),...(restoredItems||[])];
  const naRows=Object.keys(coNA).filter(k=>coNA[k]).map(k=>{
    const c=pool.find(x=>ckey(x)===k);
    return {cite:c?c.cite:k.split("|")[0], title:c?c.title:(k.split("|")[4]||""), note:coNotes[k]||"\u2014"};
  });
  const resRows=(restoredItems||[]).map(c=>({cite:c.cite,title:c.title,why:c.why||"\u2014"}));
  const remRows=Object.keys(masterRemoved).map(cite=>({cite}));
  const today=new Date().toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"});
  let h=`<div class="pd-head"><h1>CO Determinations &amp; Changes Log</h1>
    <div class="pd-sub">${officeName?esc(officeName)+" \u00b7 ":""}${esc(contractNo||"(no contract number)")} \u00b7 prepared ${today} \u00b7 for the contract file</div></div>
  <div class="pmsline"><b>${naRows.length}</b> marked N/A \u00b7 <b>${resRows.length}</b> restored after screening \u00b7 <b>${remRows.length}</b> removed from parent</div>`;
  if(naRows.length){
    h+=`<h2>Marked not applicable by the CO \u2014 ${naRows.length}</h2>
    <table><colgroup><col style="width:86pt"><col><col style="width:200pt"></colgroup>
    <thead><tr><th>Cite</th><th>Title</th><th>CO reason / note</th></tr></thead><tbody>`;
    for(const r of naRows)h+=`<tr><td class="pd-no">${esc(r.cite)}</td><td>${esc(r.title)}</td><td>${esc(r.note)}</td></tr>`;
    h+=`</tbody></table>`;
  }
  if(resRows.length){
    h+=`<h2>Restored to the list after screening \u2014 ${resRows.length}</h2>
    <table><colgroup><col style="width:86pt"><col><col style="width:200pt"></colgroup>
    <thead><tr><th>Cite</th><th>Title</th><th>Screening reason overridden</th></tr></thead><tbody>`;
    for(const r of resRows)h+=`<tr><td class="pd-no">${esc(r.cite)}</td><td>${esc(r.title)}</td><td>${esc(r.why)}</td></tr>`;
    h+=`</tbody></table>`;
  }
  if(remRows.length){
    h+=`<h2>Removed from parent${masterNo?" "+esc(masterNo):""} \u2014 ${remRows.length}</h2>
    <table><colgroup><col style="width:86pt"><col></colgroup>
    <thead><tr><th>Cite</th><th>Effect</th></tr></thead><tbody>`;
    for(const r of remRows)h+=`<tr><td class="pd-no">${esc(r.cite)}</td><td>Not treated as flowed from the parent \u2014 returned to this order's own list.</td></tr>`;
    h+=`</tbody></table>`;
  }
  if(!naRows.length&&!resRows.length&&!remRows.length)h+=`<p style="margin:14pt 0">No CO determinations or changes recorded in this session.</p>`;
  h+=`<div class="pd-note">Assembled from this session's CO actions in the clause station. Pair with the clause attachment prints for the complete file record.</div>
  <div class="pd-sig"><div>Contracting Officer: ______________________________ &nbsp;&nbsp; Date: ____________</div></div>`;
  const pd=document.getElementById("printdoc"); pd.innerHTML=h;
  document.body.classList.add("printing"); window.print();
  setTimeout(()=>{document.body.classList.remove("printing");},300);
}
