/* ===== MODULE 10: sections ===== */
const UCF_LABELS={B:"Supplies or Services and Prices/Costs",C:"Description / Specifications / Statement of Work",D:"Packaging and Marking",E:"Inspection and Acceptance",F:"Deliveries or Performance",G:"Contract Administration Data",H:"Special Contract Requirements",I:"Contract Clauses",J:"List of Attachments",K:"Representations, Certifications, and Other Statements of Offerors",L:"Instructions, Conditions, and Notices to Offerors or Respondents",M:"Evaluation Factors for Award"};
function ucfOf(c){return ((c.ucf||"").trim().toUpperCase().charAt(0))||"";}
function copySection(u){
  if(!results)return;
  const items=[...results.filter(c=>!coNA[ckey(c)]&&!c.inMaster),...restoredItems].filter(c=>ucfOf(c)===u)
    .sort((a,b)=>a.cite.localeCompare(b.cite,undefined,{numeric:true}));
  if(!items.length){document.getElementById("toolmsg").textContent="No Section "+u+" items in the current list.";return;}
  let marks=false;
  const lines=items.map(c=>{
    const f=c.fill?" ‡":"", n=/^n/i.test(c.ibr||"")?" °":"";
    if(f||n)marks=true;
    return c.cite+(c.alt?" Alt "+c.alt:"")+(c.dev?" (Dev "+c.dev+")":"")+"\t"+c.title+"\t("+c.date+")"+f+n;
  });
  let text="SECTION "+u+" — "+(UCF_LABELS[u]||"").toUpperCase()+"\n("+items.length+" provisions/clauses — generated "+new Date().toLocaleDateString()+" from "+MATRIX_LABEL+")\n\n"+lines.join("\n");
  if(marks)text+="\n\n‡ contains fill-in material — see the full-text attachment\n° incorporation by reference not authorized — set out in full text";
  const done=()=>{document.getElementById("toolmsg").textContent="Section "+u+" block copied ✓";setTimeout(()=>document.getElementById("toolmsg").textContent="",2500);};
  if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(text).then(done).catch(()=>fallbackCopy(text,done));
  else fallbackCopy(text,done);
}
let _allOpen=false;
function toggleAllPresc(btn){
  _allOpen=!_allOpen;
  document.querySelectorAll("#out .row").forEach(r=>r.classList.toggle("open",_allOpen));
  if(btn)btn.textContent=_allOpen?"Collapse prescriptions":"Expand prescriptions";
}
function esc(s){return (s||"").toString().replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}

function profileLine(){
  const parts=[];
  QS.forEach(s=>{
    if(s.cond&&!s.cond())return;
    if(s.money){if(typeof state[s.id]==="number")parts.push("Est. value "+fmtMoney(state[s.id]));return;}
    const opts=s.id==="purpose"?(state.comm==="C"?PURPOSES_C:PURPOSES_NC):s.opts;
    const op=opts.find(x=>x[0]===state[s.id]);
    if(op)parts.push(op[1]);
  });
  return parts.join(" \u00b7 ");
}

