/* ===== MODULE 11: records ===== */
function saveSession(){
  const sess={v:5,saved:new Date().toISOString(),matrix:MATRIX_LABEL,contractNo,state,refState,coNA,fillValues,reviewed,coNotes,autoScreenDeps,valText,masterText,masterNo,coRestore,masterExtra,masterRemoved,pmState,pmDone,pmNotes,pmMeta,csState,csDone,csNotes,csMeta,csRecv,csPM,csPalt,templateLinks,officeCfg,officeName,filt};
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([JSON.stringify(sess,null,1)],{type:"application/json"}));
  const safe=(contractNo||"clause-session").replace(/[^\w\-\.]+/g,"_");
  a.download=safe+"_"+new Date().toISOString().slice(0,10)+".json"; a.click();
  dirty=false;
  document.getElementById("toolmsg").textContent="Session saved \u2713";
}
async function loadSessionFile(file){
  if(!file)return;
  const msg=document.getElementById("toolmsg");
  try{
    const sess=JSON.parse(await file.text());
    if(!sess.state)throw new Error("not a session file");
    Object.assign(state,sess.state);
    if(!state.doctype)state.doctype="prime_sol";
    if(typeof state.value==="string"){const map={t1:350000,t2:2000000,t3:7500000,t4:10000000};state.value=map[state.value]||null;
      document.getElementById("toolmsg").textContent="Note: session used value tiers — converted to "+(state.value?fmtMoney(state.value):"(unset)")+"; adjust Q8 if needed.";}
    Object.keys(refState).forEach(k=>refState[k]=(sess.refState&&sess.refState[k])||"unk");
    for(const k in coNA)delete coNA[k];
    Object.assign(coNA,sess.coNA||{});
    for(const k in coRestore)delete coRestore[k];
    Object.assign(coRestore,sess.coRestore||{});
    for(const k in masterExtra)delete masterExtra[k];
    Object.assign(masterExtra,sess.masterExtra||{});
    for(const k in masterRemoved)delete masterRemoved[k];
    Object.assign(masterRemoved,sess.masterRemoved||{});
    for(const o of [pmState,pmDone,pmNotes])for(const k in o)delete o[k];
    Object.assign(pmState,sess.pmState||{});Object.assign(pmDone,sess.pmDone||{});Object.assign(pmNotes,sess.pmNotes||{});
    Object.assign(pmMeta,sess.pmMeta||{program:"",pm:""});
    for(const o of [csState,csDone,csNotes])for(const k in o)delete o[k];
    Object.assign(csState,sess.csState||{});Object.assign(csDone,sess.csDone||{});Object.assign(csNotes,sess.csNotes||{});
    Object.assign(csMeta,sess.csMeta||{program:"",cs:""});
    for(const o of [csRecv,csPM,csPalt])for(const k in o)delete o[k];
    Object.assign(csRecv,sess.csRecv||{});Object.assign(csPM,sess.csPM||{});
    for(const k in csPalt)delete csPalt[k];Object.assign(csPalt,sess.csPalt||{});
    templateLinks=Array.isArray(sess.templateLinks)?sess.templateLinks:[...DEFAULT_TEMPLATE_LINKS];
    officeCfg=sess.officeCfg||null;
    officeName=sess.officeName||"";
    for(const k in fillValues)delete fillValues[k];
    Object.assign(fillValues,sess.fillValues||{});
    for(const k in reviewed)delete reviewed[k]; Object.assign(reviewed,sess.reviewed||{});
    for(const k in coNotes)delete coNotes[k]; Object.assign(coNotes,sess.coNotes||{});
    contractNo=sess.contractNo||"";
    Object.assign(filt,sess.filt||{});
    valText=sess.valText||"";valReport=null;masterText=sess.masterText||"";masterNo=sess.masterNo||"";masterSet=new Set();{let m;CITE_RE.lastIndex=0;while((m=CITE_RE.exec(masterText)))masterSet.add(m[1]);}
    if(typeof sess.autoScreenDeps==="boolean"){autoScreenDeps=sess.autoScreenDeps;const cb=document.getElementById("asdep");if(cb)cb.checked=autoScreenDeps;}
    renderWizard();
    const allDone=QS.every(s=>(s.cond&&!s.cond())||(s.money?typeof state[s.id]==='number':state[s.id]!==null));
    if(allDone)run(true); else renderResults();
    let warn="";
    if(sess.matrix&&sess.matrix!==MATRIX_LABEL)warn=" \u26a0 session was made against \u201c"+sess.matrix+"\u201d; currently loaded: \u201c"+MATRIX_LABEL+"\u201d.";
    msg.textContent="Session loaded \u2713"+warn;
  }catch(e){msg.textContent="Could not load session: "+e.message;}
  document.getElementById("sfile").value="";
}

function recordRows(){
  const rows=[["FOR TESTING ONLY - NOT FOR OPERATIONAL USE - verify all outputs independently"],["Cite","Title","P/C","Classification","Regulation","RFO Status","UCF","Date","Prescribed At","Threshold Hint","Fill-In","Fill-In Entries","Flowdown","Reviewed","Working Note","Status","Reason / CO Note","Prescription"]];
  const dump=(c,status,why)=>rows.push([c.cite,c.title,c.pc.startsWith("P")?"Provision":"Clause",
    c.cls==="R"?"Required":c.cls==="A"?"Required when applicable":"Optional",
    regLabel(c.reg),c.rfo,c.ucf,c.date,c.presc_at,c.thrFlag?("$"+fmt(c.thr)):"",c.fill?"Yes":"",c.fill&&c.full?tokenizeFull(c.full,c.title).filter(t=>t.t==="b"||t.t==="cb").map(t=>{const st=(fillValues[ckey(c)]||{});if(t.t==="cb")return st[t.i]==="1"?"[x] "+t.label:null;const v=(st[t.i]||"").trim();return v?t.label+" = "+v:null}).filter(Boolean).join("; "):"",(c.nsubk||c.csubk)?"Yes":"",reviewed[ckey(c)]?"Yes":"",coNotes[ckey(c)]||"",status,why||"",c.presc]);
  results.forEach(c=>{const na=coNA[ckey(c)];dump(c,na?"CO determined N/A":(c.inMaster?("In list (parent "+(masterNo||"IDIQ/BPA")+")"):"In list"),na?na.reason:"")});
  restoredItems.forEach(c=>dump(c,"Screened — restored by CO",c.why||""));
  screened.forEach(c=>dump(c,"Screened by refinement",c.why));
  return rows;
}
function exportCSV(){
  if(!results){alert("Generate a clause list first.");return;}
  const rows=recordRows();
  const csv=rows.map(r=>r.map(v=>`"${(v||"").toString().replace(/"/g,'""')}"`).join(",")).join("\r\n");
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));
  a.download="clause_list.csv";a.click();
  dirty=false;
}

function exportXLS(){
  if(!results){alert("Generate a clause list first.");return;}
  const rows=recordRows();
  const warn=rows[0][0], headers=rows[1], body=rows.slice(2);
  const esc2=s=>esc(String(s==null?"":s));
  let h=`<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"><style>
  @page{size:landscape;margin:.5in}
  body{font:9pt Calibri,Arial,sans-serif}
  table{border-collapse:collapse;width:100%}
  thead{display:table-header-group}
  th{background:#10243e;color:#fff;font:bold 9pt Calibri;border:.5pt solid #10243e;padding:3pt 5pt;text-align:left;vertical-align:bottom}
  td{border:.5pt solid #b9b2a0;padding:3pt 5pt;vertical-align:top;mso-number-format:"\\@"}
  tr.warn td{background:#fffbeb;color:#92400e;font-weight:bold;border:1pt solid #b45309}
  tr.meta td{background:#f3f1ea;border:none;font-style:italic}
  tbody tr:nth-child(even) td{background:#faf8f2}
  </style></head><body><table>
  <colgroup><col width="90"><col width="280"><col width="34"><col width="40"><col width="62"><col width="36"><col width="60"><col width="60"><col width="40"><col width="44"><col width="200"><col width="56"><col width="56"><col width="160"><col width="150"><col width="200"><col width="420"></colgroup>
  <tr class="warn"><td colspan="${headers.length}">${esc2(warn)}</td></tr>
  <tr class="meta"><td colspan="${headers.length}">Generated ${esc2(new Date().toLocaleString())} \u00b7 ${esc2(MATRIX_LABEL)} \u00b7 ${esc2(profileLine())}${contractNo?` \u00b7 ${esc2(contractNo)}`:""}</td></tr>
  <thead><tr>${headers.map(x=>`<th>${esc2(x)}</th>`).join("")}</tr></thead><tbody>`;
  for(const row of body)h+=`<tr>${row.map(x=>`<td>${esc2(x)}</td>`).join("")}</tr>`;
  h+=`</tbody></table></body></html>`;
  const blob=new Blob(["\ufeff"+h],{type:"application/vnd.ms-excel"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);
  const safe=(contractNo||"clause_records").replace(/[^\w.-]+/g,"_");
  a.download=safe+"_"+new Date().toISOString().slice(0,10)+".xls"; a.click();
  dirty=false;
}

function resetAll(){for(const k in state)state[k]=null;REF.forEach(r=>refState[r.id]="unk");results=null;screened=null;for(const k in coNA)delete coNA[k];for(const k in coRestore)delete coRestore[k];restoredItems=[];for(const k in fillValues)delete fillValues[k];for(const k in reviewed)delete reviewed[k];for(const k in coNotes)delete coNotes[k];contractNo="";valText="";valReport=null;showVal=false;masterText="";masterNo="";masterSet=new Set();masterItems=[];for(const k in masterExtra)delete masterExtra[k];showMaster=false;filt={text:"",cls:"all",pc:"all",hideThr:false,fillOnly:false,byUcf:false};for(const k in masterRemoved)delete masterRemoved[k];for(const k in autoScreenDeps)delete autoScreenDeps[k];for(const o of [pmState,pmDone,pmNotes])for(const k in o)delete o[k];pmMeta.program="";pmMeta.pm="";for(const o of [csState,csDone,csNotes,csRecv,csPM,csPalt])for(const k in o)delete o[k];csMeta.program="";csMeta.cs="";csPkg=null;templateLinks=[...DEFAULT_TEMPLATE_LINKS];if(officeCfg)applyOfficeCfg(officeCfg);renderWizard();renderResults();renderHub();}
