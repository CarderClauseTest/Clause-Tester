/* ===== MODULE 14: pm_station ===== */
/* PM package questionnaire. The document catalog (PM_DOCS) is data, not code:
   each entry gains `template` and `guidance` fields later without engine changes.
   Acronym expansions marked (confirm) are best readings — correct them in this catalog. */
const ASP_THRESHOLD = 10000000; // office-set review threshold — confirm and adjust

const PM_DOCS = {
  pd:   {name:"Procurement Directive", full:"Memo from the PM requesting Contracting start an acquisition — explains what is being bought and how", owner:"PM"},
  igce: {name:"IGCE", full:"Independent Government Cost Estimate", owner:"PM"},
  fal:  {name:"FAL", full:"Funds Assurance Letter", owner:"PM / Resource mgr"},
  mrr:  {name:"Market Research Report", full:"Market research documentation (standard addition — remove if your office folds this elsewhere)", owner:"PM, with CS"},
  sow:  {name:"SOW", full:"Statement of Work", owner:"PM"},
  soo:  {name:"SOO", full:"Statement of Objectives", owner:"PM"},
  trd:  {name:"TRD", full:"Technical Requirements Document", owner:"PM / Engineering"},
  asp:  {name:"ASP", full:"Acquisition Strategy Plan", owner:"PM, with CO"},
  jna:  {name:"J&A", full:"Justification & Approval (FAR Part 6 other-than-full-and-open)", owner:"PM drafts, CO completes"},
  lsj:  {name:"LSJ", full:"Limited Sources Justification (Federal Supply Schedule orders)", owner:"PM drafts, CO completes"},
  foe:  {name:"FOE", full:"Fair Opportunity Exception (orders under multiple-award contracts)", owner:"PM drafts, CO completes"},
  sb3:  {name:"SBIR Phase III Justification", full:"Documents the Phase III relationship to prior SBIR/STTR work", owner:"PM drafts, CO completes"},
  scope:{name:"Within-scope statement", full:"Statement supporting in-scope order under the existing single-award vehicle", owner:"PM, with CO"},
  qasp: {name:"QASP", full:"Quality Assurance Surveillance Plan (standard addition for performance-based services)", owner:"PM"},
  ota:  {name:"OT Justification", full:"Basis for using Other Transaction authority (nontraditional participation / cost share / agency determination)", owner:"PM, with Agreements Officer"},
  cso:  {name:"CSO input", full:"Commercial Solutions Opening — problem statement / area of interest for the announcement", owner:"PM"},
  bpaj: {name:"Limited-source support (BPA call)", full:"LSJ if the BPA is schedule-based; simplified sole-source justification if it is a Part 13 BPA — confirm BPA type with the CO", owner:"PM drafts, CO completes"},
  sec:  {name:"Security input", full:"Security classification guidance (e.g., DD Form 254 input)", owner:"PM / Security"},
  itap: {name:"IT approval", full:"Agency IT approval documentation (per your office's process)", owner:"PM / IT"},
};

const PM_QS = [
  {id:"buy", q:"What are you buying?", opts:[["sup","Supplies / equipment"],["svc","Services"],["rd","Research & development"],["con","Construction"],["it","IT / software"]]},
  {id:"desc", q:"How will the requirement be described?", help:"SOW tells industry how; SOO states objectives and lets industry propose how; TRD specifies technical performance for systems/hardware.", opts:[["sow","Detailed tasks — SOW"],["soo","Objectives only — SOO"],["trd","Technical specification — TRD"],["unsure","Not sure yet"]]},
  {id:"val", q:"Estimated total value (all years/options)?", money:true},
  {id:"newreq", q:"Is this new, or a follow-on / recompete?", opts:[["new","New requirement"],["follow","Follow-on / recompete"]]},
  {id:"vehicle", q:"Where do you expect this to be bought?", opts:[["open","Open market (new contract)"],["fss","GSA / Federal Supply Schedule"],["mac","Existing multiple-award IDIQ (MAC/GWAC)"],["single","Existing single-award IDIQ"],["bpa","Existing BPA (call/order)"],["ota","Other Transaction (OTA)"],["cso","Commercial Solutions Opening"],["mod","Modify an existing contract"],["sbir3","SBIR/STTR Phase III follow-on"],["unsure","Not sure yet"]]},
  {id:"comp", q:"Competition intent?", opts:[["full","Compete it fully"],["brand","Limit to a brand name"],["sole","Limit to one source"],["unsure","Not sure yet"]]},
  {id:"sbir", q:"Does the work derive from prior SBIR/STTR effort?", opts:[["yes","Yes"],["no","No"],["unsure","Not sure"]]},
  {id:"classified", q:"Classified or CUI involved?", opts:[["yes","Yes"],["no","No"]]},
  {id:"itq", q:"Does it touch Government IT systems?", opts:[["yes","Yes"],["no","No"]]},
  {id:"pop", q:"Planned period of performance (free text)", text:true},
];

/* ===== template links (admin-fillable, chip input: comma / Tab / Enter commits) ===== */
const DEFAULT_TEMPLATE_LINKS=[]; // bake office defaults here, e.g. ["https://intranet/.../templates"]
let templateLinks=[...DEFAULT_TEMPLATE_LINKS];
function tplHref(v){
  if(/^\\\\/.test(v))return "file:"+v.replace(/\\/g,"/");
  if(/^[a-z][a-z0-9+.-]*:/i.test(v))return v;
  return "https://"+v;
}
function tplLabel(v){
  const s=v.replace(/^[a-z]+:\/\//i,"").replace(/^www\./i,"");
  return s.length>44?s.slice(0,26)+"\u2026"+s.slice(-15):s;
}
function commitTpl(raw,view){
  for(const part of String(raw).split(",")){
    const v=part.trim().replace(/,+$/,"");
    if(v&&!templateLinks.includes(v))templateLinks.push(v);
  }
  dirty=true;
  if(view==="pm")renderPM(); else if(view==="cs")renderCS(); else renderHub();
}
function removeTpl(i,view){
  templateLinks.splice(i,1);dirty=true;
  if(view==="pm")renderPM(); else if(view==="cs")renderCS(); else renderHub();
}
function tplKey(e,view){
  const el=e.target;
  if(e.key===","||e.key==="Tab"||e.key==="Enter"){
    if(el.value.trim()){e.preventDefault();const v=el.value;el.value="";commitTpl(v,view);}
    else if(e.key===",")e.preventDefault();
  } else if(e.key==="Backspace"&&!el.value&&templateLinks.length){
    e.preventDefault();
    el.dataset.restore=templateLinks[templateLinks.length-1];
    templateLinks.pop();dirty=true;
    if(view==="pm")renderPM(); else if(view==="cs")renderCS(); else renderHub();
    const ni=document.getElementById("tplin-"+view); if(ni){ni.value=el.dataset.restore;}
  }
}
function tplLinksHTML(view){
  return `<div class="tplwrap"><span class="tpllbl" title="Where users find document templates \u2014 type a URL or \\\\server\\share path; comma, Tab, or Enter adds it">Template links</span>
    ${templateLinks.map((v,i)=>`<span class="tplchip"><a href="${esc(tplHref(v))}" target="_blank" rel="noopener" title="${esc(v)}">${esc(tplLabel(v))}</a><button class="tplx" onclick="removeTpl(${i},'${view}')" title="Remove">\u00d7</button></span>`).join("")}
    <input id="tplin-${view}" class="tplin" type="text" placeholder="${templateLinks.length?"add another\u2026":"paste a template location, then comma or Tab"}" onkeydown="tplKey(event,'${view}')" onblur="if(this.value.trim()){const v=this.value;this.value='';commitTpl(v,'${view}');}"></div>`;
}
/* ===== office configuration (drop-in JSON at the hub) ===== */
let officeCfg=null; let officeName="";
function docNote(id){return officeCfg&&officeCfg.docNotes&&officeCfg.docNotes[id]?officeCfg.docNotes[id]:null;}
function docNoteHTML(id){const n=docNote(id);return n?`<div class="offnote"><b>Office</b> ${esc(n)}</div>`:"";}
function applyOfficeCfg(cfg){
  officeCfg=cfg;
  if(cfg.office&&!officeName)officeName=cfg.office;
  for(const v of cfg.templateLinks||[])if(!templateLinks.includes(v))templateLinks.push(v);
  for(const k in (cfg.pm||{}))if(pmState[k]===undefined||pmState[k]==="")pmState[k]=cfg.pm[k];
  for(const k in (cfg.cs||{}))if(csState[k]===undefined||csState[k]==="")csState[k]=cfg.cs[k];
  const cl=cfg.clauses||{};
  for(const k in (cl.profile||{}))if(state[k]===undefined||state[k]===null||state[k]==="")state[k]=cl.profile[k];
  for(const k in (cl.conditions||{}))if(refState[k]===undefined||refState[k]==="unk"||refState[k]==="unsure"||refState[k]==="")refState[k]=cl.conditions[k];
  dirty=true;
}
function loadOfficeFile(file){
  const r=new FileReader();
  r.onload=()=>{try{
    const cfg=JSON.parse(r.result);
    if(cfg.kind!=="office-config")throw 0;
    applyOfficeCfg(cfg);
    renderHub();
  }catch(e){alert("Not an office configuration file. Download the example from the hub to see the format.");}};
  r.readAsText(file);
}
function clearOfficeCfg(){officeCfg=null;dirty=true;renderHub();}
function downloadOfficeExample(){
  const ex={kind:"office-config",v:1,office:"Your office name",
    templateLinks:["https://intranet.example/contracting/templates"],
    pm:{vehicle:"mac"},
    cs:{sat:"over"},
    clauses:{profile:{rfo:"yes",agency:"dod"},conditions:{}},
    docNotes:{
      igce:"Example tip: attach the cost-buildup tab \u2014 reviews bounce without it.",
      jna:"Example lesson learned: route through legal regardless of value.",
      c2597:"Example: use the fillable 2597 on the shared drive, not the scanned copy."
    }};
  const blob=new Blob([JSON.stringify(ex,null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob);
  a.download="office-config-example.json"; a.click();
}
function officeBlockHTML(){
  return `<div class="offblock">
    <div class="offrow"><span class="tpllbl">Office setup</span>
      <input type="text" class="offname" placeholder="Office name (optional)" value="${esc(officeName)}" oninput="officeName=this.value;dirty=true" onchange="renderHub()">
      <label class="ghost csimp">Load office file (.json)<input type="file" accept=".json" style="display:none" onchange="if(this.files[0])loadOfficeFile(this.files[0])"></label>
      <button class="ghost" onclick="downloadOfficeExample()">Download example office file</button>
      ${officeCfg?`<span class="cschip ok">Office file: ${esc(officeCfg.office||"loaded")} \u2713</span><button class="tplx" onclick="clearOfficeCfg()" title="Stop using this office file">\u00d7</button>`:""}
    </div>
    <p class="offhelp">An office file pre-selects questionnaire and clause answers (filling blanks only \u2014 it never overwrites work in progress), adds template links, and attaches the office's tips and lessons learned to each document. <b>Start over</b> keeps it applied.</p>
    ${tplLinksHTML("hub")}
  </div>`;
}
function tplChipsRO(){
  if(!templateLinks.length)return "";
  return `<div class="tplwrap ro"><span class="tpllbl" title="Edit on the hub">Templates</span>
    ${templateLinks.map(v=>`<span class="tplchip"><a href="${esc(tplHref(v))}" target="_blank" rel="noopener" title="${esc(v)}">${esc(tplLabel(v))}</a></span>`).join("")}</div>`;
}

const pmState = {}; const pmDone = {}; const pmNotes = {};
const pmMeta = {program:"", pm:""};

/* shared vehicle + competition document logic — used by both PM and CS stations */
function vehCompDocs(ctx){
  const list=[]; const A=(id,why)=>list.push({id,why});
  const veh=ctx.veh, c=ctx.comp, limited=(c==="sole"||c==="brand");
  const sbirPath = veh==="sbir3" || (ctx.sbir==="yes" && c==="sole");
  if(veh==="ota")A("ota","Other Transactions sit outside the FAR competition framework — the OT justification is the basis document.");
  if(veh==="cso"){
    A("cso","A CSO is a competitive procedure — the announcement's problem statement is the input.");
    if(limited)list.push({pseudo:{id:"cso!",name:"Check: CSO vs. sole source",full:"A CSO is inherently competitive — a single intended source points to a different vehicle",owner:"With CO",why:"A CSO was picked but sources are limited; resolve before proceeding.",group:"cond"}});
  }
  if(veh==="single")A("scope","Orders under a single-award vehicle need support that the work is within scope.");
  if(veh==="mod")A("scope","An in-scope modification needs the within-scope basis documented; out-of-scope work needs a new acquisition.");
  if(veh==="bpa"){
    A("scope","BPA calls must be within the BPA's scope and terms.");
    if(limited)A("bpaj","Limiting sources on a BPA call — document type follows the BPA type.");
  }
  if(sbirPath){
    A("sb3","Phase III follow-on of prior SBIR/STTR work — used in lieu of a standard FAR competition justification (confirm with CO).");
  } else if(veh==="open"&&limited){
    A("jna",(c==="brand"?"Brand-name limit on the open market — brand-name J&A. ":"Single source on the open market — J&A. ")+"Approval level scales with value; confirm thresholds with contracting.");
  } else if(veh==="fss"&&limited){
    A("lsj","Limiting sources on a Schedule order — LSJ rather than a J&A.");
  } else if(veh==="mac"&&limited){
    A("foe","Limiting an order under a multiple-award contract — Fair Opportunity Exception rather than a J&A.");
  } else if(limited&&veh==="unsure"){
    list.push({pseudo:{id:"just?",name:"Competition justification — type depends on vehicle",full:"Open market → J&A · FSS/BPA → LSJ · Multiple-award IDIQ → FOE · OTA → OT justification · SBIR Phase III → SBIR justification",owner:"PM drafts, CO completes",why:"Competition will be limited but the vehicle is undecided; the vehicle decides which document applies.",group:"cond"}});
  }
  if(ctx.followon){const j=list.find(x=>x.id==="jna"); if(j)j.why+=" Follow-on: address why transitioning from the incumbent is not practicable.";}
  return list;
}

function pmDocsFor(ans){
  const out = []; const add=(id,why,group)=>out.push({id,why,group,...PM_DOCS[id]});
  add("pd","Initiates the acquisition — tells Contracting what is being bought and how.","core");
  add("igce","Required for every package; basis for funding and price reasonableness.","core");
  add("fal","Confirms funds are available and cited for the requirement.","core");
  add("mrr","Market research underpins strategy, set-aside, and any justification below.","core");
  const d=ans.desc, b=ans.buy;
  if(d==="sow")add("sow","You chose a detailed task description.","cond");
  else if(d==="soo")add("soo","You chose an objectives-based description; the offeror's PWS follows.","cond");
  else if(d==="trd")add("trd","You chose a technical specification.","cond");
  else if(d==="unsure")out.push({id:"desc?",name:"Requirement description (SOW / SOO / TRD)",full:"Pick one with your CS — exactly one primary description document is needed.",owner:"PM",why:"Undecided — the package cannot move without one.",group:"cond"});
  if((b==="sup"||b==="rd")&&d==="sow")add("trd","Hardware/technical buys described by SOW usually carry a supporting TRD — confirm with engineering.","cond");
  const v=typeof ans.val==="number"?ans.val:null;
  if(v!==null&&v>=ASP_THRESHOLD)add("asp",`Estimated value meets the written acquisition-strategy-plan threshold ($${(ASP_THRESHOLD/1e6)}M — office-set, adjust ASP_THRESHOLD).`,"cond");
  // vehicle + competition (shared engine — also used by the CS station)
  for(const e of vehCompDocs({veh:ans.vehicle,comp:ans.comp,sbir:ans.sbir,followon:ans.newreq==="follow"})){
    if(e.pseudo)out.push(e.pseudo); else add(e.id,e.why,"cond");
  }
  if(v!==null&&v<=350000)out.push({id:"sap",name:"Simplified-threshold note",full:"At or below the simplified threshold used in your matrix",owner:"PM, with CO",why:"Several items above may be abbreviated under simplified procedures — confirm with your CO.",group:"cond"});
  if(b==="svc"&&(d==="sow"||d==="soo"))add("qasp","Performance-based services carry a surveillance plan.","cond");
  if(ans.classified==="yes")add("sec","Classified/CUI work needs security classification guidance in the package.","cond");
  if(ans.itq==="yes")add("itap","IT involvement triggers your office's IT approval chain.","cond");
  return out;
}
function pmDocList(){return pmDocsFor(pmState);}

function pmReadiness(){
  const docs=pmDocList(); const flags=[];
  const F=(level,msg)=>flags.push({level,msg});
  const done=id=>!!pmDone[id];
  if(docs.some(d=>d.id==="fal")&&!done("fal"))F("stop","Funding not assured \u2014 the FAL is not marked done; the package cannot move without it.");
  const descIds=["sow","soo","trd"]; const needDesc=docs.find(d=>descIds.includes(d.id));
  if(pmState.desc==="unsure")F("stop","Requirement description undecided \u2014 pick SOW, SOO, or TRD before handoff.");
  else if(needDesc&&!done(needDesc.id))F("warn",`${needDesc.name} not marked done \u2014 the description document is the package's core.`);
  if(!done("igce"))F("warn","IGCE not marked done \u2014 contracting cannot assess funding or price reasonableness without it.");
  if(typeof pmState.val!=="number")F("warn","No estimated value entered \u2014 thresholds (ASP, SAT, approval levels) cannot be checked.");
  if((pmState.comp==="sole"||pmState.comp==="brand")&&pmState.vehicle==="unsure")F("warn","Competition will be limited but the vehicle is undecided \u2014 the justification type is unresolved.");
  if(pmState.classified==="yes")F("info","Classified/CUI \u2014 security input (DD254-type) has long lead time; start it early.");
  if(pmState.sbir==="yes"&&pmState.comp==="full")F("info","SBIR-derived but competing fully \u2014 confirm the data-rights posture with contracting before release.");
  return flags;
}
function pmReadinessHTML(){
  const flags=pmReadiness();
  if(!flags.length)return `<div class="rdy"><span class="rdychip ok">Readiness check \u00b7 no blockers</span></div>`;
  const lab={stop:"Blocker",warn:"Check",info:"Note"};
  return `<div class="rdy"><span class="rdychip ${flags.some(f=>f.level==="stop")?"stop":"warn"}">Readiness check \u00b7 ${flags.length} item${flags.length>1?"s":""}</span>
    ${flags.map(f=>`<div class="rdyrow ${f.level}"><b>${lab[f.level]}</b> ${esc(f.msg)}</div>`).join("")}</div>`;
}

function pmCopySummary(btn){
  const docs=pmDocList();
  const done=docs.filter(d=>pmDone[d.id]).length;
  const pending=docs.filter(d=>!pmDone[d.id]).map(d=>d.name);
  const fl=pmReadiness();
  const vline=typeof pmState.val==="number"?"$"+pmState.val.toLocaleString():"value TBD";
  const t=[
    `${pmMeta.program||"(program)"} \u2014 ${PM_L.buy[pmState.buy]||"requirement"}, est. ${vline}${pmState.pop?", PoP "+pmState.pop:""}.`,
    `Vehicle: ${PM_L.vehicle[pmState.vehicle]||"TBD"}; competition: ${PM_L.comp[pmState.comp]||"TBD"}${pmState.sbir==="yes"?"; SBIR-derived":""}${pmState.classified==="yes"?"; classified/CUI":""}.`,
    `Package: ${done} of ${docs.length} documents prepared${pending.length?". Outstanding: "+pending.join(", ")+".":" \u2014 complete."}`,
    fl.length?`Readiness: ${fl.map(f=>f.msg).join(" ")}`:`Readiness: no blockers.`
  ].join("\n");
  const ok=()=>{const o=btn.textContent;btn.textContent="Copied \u2713";setTimeout(()=>btn.textContent=o,1600);};
  if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).then(ok).catch(()=>fallbackCopy(t,ok));
  else fallbackCopy(t,ok);
}
function printCoverSheet(){
  const P=hubProg();
  const today=new Date().toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"});
  const prog=pmMeta.program||csMeta.program||"\u2014";
  const v=typeof pmState.val==="number"?pmState.val:(typeof csState.val==="number"?csState.val:null);
  let h=`<div class="pd-head"><h1>Acquisition Package \u2014 Cover &amp; Routing</h1>
    <div class="pd-sub">${officeName?esc(officeName)+" \u00b7 ":""}${esc(prog)} \u00b7 prepared ${today} \u00b7 testing only</div></div>
  <div class="pms">
    <span><b>Program</b>${esc(prog)}</span>
    <span><b>PM</b>${esc(pmMeta.pm||"\u2014")}</span>
    <span><b>Specialist</b>${esc(csMeta.cs||"\u2014")}</span>
    <span><b>Est. value</b>${v!==null?"$"+v.toLocaleString():"\u2014"}</span>
    <span><b>Vehicle</b>${esc(PM_L.vehicle[csState.vehicle||pmState.vehicle]||"\u2014")}</span>
    <span><b>Method</b>${esc(CS_L.method[csState.method]||"\u2014")}</span>
    <span><b>SAT band</b>${esc(CS_L.sat[csState.sat]||"\u2014")}</span>
    <span><b>Date</b>${today}</span>
  </div>
  <h2>Routing</h2>
  <table><colgroup><col style="width:150pt"><col><col style="width:130pt"><col style="width:70pt"></colgroup>
  <thead><tr><th>Station</th><th>Status at print</th><th>Signature</th><th>Date</th></tr></thead><tbody>
  <tr><td class="pd-no">PM \u2014 requirements package</td><td>${esc(P.pm)}</td><td>____________________</td><td>________</td></tr>
  <tr><td class="pd-no">CO/CS \u2014 acquisition documentation</td><td>${esc(P.cs)}</td><td>____________________</td><td>________</td></tr>
  <tr><td class="pd-no">Clause &amp; provision list</td><td>${esc(P.cl)}</td><td>____________________</td><td>________</td></tr>
  </tbody></table>
  <div class="pd-note">Cover sheet generated from live station status. Attach the PM checklist, the CO/CS acquisition checklist, the milestone schedule, the CO log, and the clause attachments behind this sheet.</div>`;
  const pd=document.getElementById("printdoc"); pd.innerHTML=h;
  document.body.classList.add("printing"); window.print();
  setTimeout(()=>{document.body.classList.remove("printing");},300);
}

function renderPM(){
  const host=document.getElementById("pmview"); if(!host)return;
  let h=`<div class="pmhead"><button class="ghost" onclick="showView('hub')">&#8962; Hub</button>
    <h1>PM station — requirements package</h1>
    <p class="pmsub">Answer what you're buying; the tool returns the documentation your package needs, each with the reason. Templates and guidance attach to these same rows later.</p></div>`;
  h+=`<div class="pmmeta"><input type="text" placeholder="Program / requirement name" value="${esc(pmMeta.program)}" oninput="pmMeta.program=this.value;dirty=true">
      <input type="text" placeholder="PM name" value="${esc(pmMeta.pm)}" oninput="pmMeta.pm=this.value;dirty=true"></div>`;
  for(const q of PM_QS){
    const a=pmState[q.id];
    h+=`<div class="q ${a!==undefined&&a!==""?"done":""}"><div class="qt">${esc(q.q)}</div>${q.help?`<div class="qh">${esc(q.help)}</div>`:""}`;
    if(q.money){
      h+=`<input type="text" id="pmval" placeholder="e.g. 2.5M or 750K" value="${a!==undefined&&typeof a==="number"?("$"+a.toLocaleString()):""}"
        onchange="const v=parseMoney(this.value); if(v!==null){pmState.val=v;dirty=true;renderPM();}">`;
    } else if(q.text){
      h+=`<input type="text" placeholder="e.g. 12 months + four 12-month options" value="${esc(a||"")}" onchange="pmState.${q.id}=this.value;dirty=true;renderPM();">`;
    } else {
      h+=`<div class="opts">${q.opts.map(([v,l])=>`<button class="opt ${a===v?"sel":""}" onclick="pmState.${q.id}='${v}';dirty=true;renderPM();">${esc(l)}</button>`).join("")}</div>`;
    }
    h+=`</div>`;
  }
  const answered=PM_QS.filter(q=>pmState[q.id]!==undefined&&pmState[q.id]!=="").length;
  if(answered>=4){
    const docs=pmDocList();
    const stat=docs.filter(d=>pmDone[d.id]).length;
    h+=tplChipsRO();
    h+=`<div class="pmdocs"><div class="summary"><b>${docs.length}</b> documents for this package &nbsp;\u00b7&nbsp; ${stat} marked done
      <span style="float:right"><button class="ghost" onclick="pmCopySummary(this)">Copy summary</button>
      <button class="primary" onclick="printPMChecklist()">Print package checklist</button>
      <button class="ghost" onclick="exportPackage()">Export package (.json)</button>
      <button class="ghost" onclick="pmToClauses()">Continue to clause station \u2192</button></span></div>`;
    h+=pmReadinessHTML();
    for(const grp of [["core","Required for every package"],["cond","Required because of your answers"]]){
      const rows=docs.filter(d=>d.group===grp[0]); if(!rows.length)continue;
      h+=`<h2 class="pmgrp">${grp[1]}</h2>`;
      h+=rows.map(d=>`<div class="row pmrow">
        <label class="pmchk"><input type="checkbox" ${pmDone[d.id]?"checked":""} onchange="pmDone['${d.id}']=this.checked?1:0;dirty=true;renderPM();"></label>
        <span><b class="pmname">${esc(d.name)}</b> <span class="pmfull">${esc(d.full)}</span><br>
          <span class="pmwhy">${esc(d.why)}</span> <span class="pmown">\u00b7 ${esc(d.owner)}</span><br>
          ${docNoteHTML(d.id)}<input type="text" class="pmnote" placeholder="working note (optional)" value="${esc(pmNotes[d.id]||"")}" oninput="pmNotes['${d.id}']=this.value;dirty=true">
        </span></div>`).join("");
    }
    h+=`</div>`;
  } else {
    h+=`<p class="pmhint">Answer at least four questions to see the document list.</p>`;
  }
  host.innerHTML=h;
}

const PM_L={
  buy:{sup:"Supplies / equipment",svc:"Services",rd:"Research & development",con:"Construction",it:"IT / software"},
  desc:{sow:"SOW (detailed tasks)",soo:"SOO (objectives)",trd:"TRD (technical spec)",unsure:"Undecided"},
  vehicle:{open:"Open market",fss:"GSA / FSS",mac:"Multiple-award IDIQ",single:"Single-award IDIQ",bpa:"Existing BPA",ota:"Other Transaction",cso:"Commercial Solutions Opening",mod:"Contract modification",sbir3:"SBIR Phase III",unsure:"Undecided"},
  comp:{full:"Full competition",brand:"Brand-name limit",sole:"Single source",unsure:"Undecided"},
  yn:{yes:"Yes",no:"No",unsure:"Unsure"}};
function printPMChecklist(){
  const docs=pmDocList();
  const today=new Date().toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"});
  const vline=typeof pmState.val==="number"?"$"+pmState.val.toLocaleString():"\u2014";
  const done=docs.filter(d=>pmDone[d.id]).length;
  const pending=docs.filter(d=>!pmDone[d.id]).map(d=>d.name);
  let h=`<div class="pd-head"><h1>Acquisition Package \u2014 Documentation Checklist</h1>
    <div class="pd-sub">${officeName?esc(officeName)+" \u00b7 ":""}${esc(pmMeta.program||"(program not named)")} \u00b7 prepared ${today}</div></div>
  <div class="pms">
    <span><b>Program</b>${esc(pmMeta.program||"\u2014")}</span>
    <span><b>PM</b>${esc(pmMeta.pm||"\u2014")}</span>
    <span><b>Est. value</b>${vline}</span>
    <span><b>Period of performance</b>${esc(pmState.pop||"\u2014")}</span>
    <span><b>Buying</b>${esc(PM_L.buy[pmState.buy]||"\u2014")}</span>
    <span><b>Described by</b>${esc(PM_L.desc[pmState.desc]||"\u2014")}</span>
    <span><b>Vehicle</b>${esc(PM_L.vehicle[pmState.vehicle]||"\u2014")}</span>
    <span><b>Competition</b>${esc(PM_L.comp[pmState.comp]||"\u2014")}</span>
    <span><b>New / follow-on</b>${pmState.newreq==="follow"?"Follow-on / recompete":pmState.newreq==="new"?"New":"\u2014"}</span>
    <span><b>SBIR-derived</b>${esc(PM_L.yn[pmState.sbir]||"\u2014")}</span>
    <span><b>Classified / CUI</b>${esc(PM_L.yn[pmState.classified]||"\u2014")}</span>
    <span><b>Touches Gov IT</b>${esc(PM_L.yn[pmState.itq]||"\u2014")}</span>
  </div>
  <div class="pmsline"><b>${done} of ${docs.length}</b> documents prepared${pending.length?` \u00b7 <b>Outstanding:</b> ${pending.map(esc).join(", ")}`:" \u00b7 package documentation complete"}</div>`;
  const rf=pmReadiness();
  if(rf.length)h+=`<div class="pd-note" style="margin:0 0 6pt"><b>Readiness:</b> ${rf.map(f=>esc(f.msg)).join(" \u00b7 ")}</div>`;
  for(const grp of [["core","Required for every package"],["cond","Required because of your answers"]]){
    const rows=docs.filter(d=>d.group===grp[0]); if(!rows.length)continue;
    const gd=rows.filter(d=>pmDone[d.id]).length;
    h+=`<h2>${grp[1]} \u2014 ${gd} of ${rows.length} prepared</h2>
    <table><colgroup><col style="width:128pt"><col><col style="width:92pt"><col style="width:34pt"></colgroup>
    <thead><tr><th>Document</th><th>Why</th><th>Owner</th><th class="pd-uc">Status</th></tr></thead><tbody>`;
    for(const d of rows)h+=`<tr><td class="pd-no">${esc(d.name)}</td><td>${esc(d.why)}${docNote(d.id)?` <i>Office: ${esc(docNote(d.id))}</i>`:""}${pmNotes[d.id]?` <i>\u2014 ${esc(pmNotes[d.id])}</i>`:""}</td><td>${esc(d.owner)}</td><td class="pd-uc">${pmDone[d.id]?"\u2611":"\u2610"}</td></tr>`;
  h+=`</tbody></table>`;}
  h+=`<div class="pd-note">Generated from the PM questionnaire \u2014 confirm against the office package checklist. Justification by vehicle: open market \u2192 J&amp;A \u00b7 FSS / FSS-BPA \u2192 LSJ \u00b7 multiple-award IDIQ \u2192 FOE \u00b7 OTA \u2192 OT justification \u00b7 CSO \u2192 competitive announcement \u00b7 SBIR Phase III \u2192 SBIR justification.</div>
  ${templateLinks.length?`<div class="pd-note"><b>Templates:</b> ${templateLinks.map(v=>esc(v)).join(" \u00b7 ")}</div>`:""}
  <div class="pd-sig"><div>Program Manager: ______________________________ &nbsp;&nbsp; Date: ____________</div></div>`;
  const pd=document.getElementById("printdoc"); pd.innerHTML=h;
  document.body.classList.add("printing"); window.print();
  setTimeout(()=>{document.body.classList.remove("printing");},300);
}
function exportPackage(){
  const docs=pmDocList();
  const pkg={kind:"acq-package",v:1,created:new Date().toISOString(),meta:{...pmMeta,office:officeName},answers:{...pmState},
    docs:docs.map(d=>({id:d.id,name:d.name,done:!!pmDone[d.id],note:pmNotes[d.id]||""})),
    flags:pmReadiness()};
  const blob=new Blob([JSON.stringify(pkg,null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob);
  a.download=(pmMeta.program||"package").replace(/[^\w.-]+/g,"_")+"_package.json"; a.click(); dirty=false;
}

function pmToClauses(){
  if(typeof pmState.val==="number")state.value=pmState.val;
  const map={sup:"nsup",svc:"nsvc",rd:"rd",con:"con"};
  if(map[pmState.buy])state.purpose=map[pmState.buy];
  state.doctype="prime_sol";
  showView("clauses"); renderWizard();
  const tm=document.getElementById("toolmsg"); if(tm){tm.textContent="Profile seeded from the PM package \u2014 confirm each answer."; setTimeout(()=>tm.textContent="",4000);}
}

/* ===== hub + view switching ===== */
let currentView="hub";
function showView(v){
  currentView=v;
  const hub=document.getElementById("hub"), pm=document.getElementById("pmview"), app=document.getElementById("clausesApp");
  if(!hub||!pm||!app)return;
  hub.style.display=v==="hub"?"":"none";
  pm.style.display=v==="pm"?"":"none";
  const cs=document.getElementById("csview"); if(cs)cs.style.display=v==="cs"?"":"none";
  app.style.display=v==="clauses"?"":"none";
  if(v==="hub")renderHub();
  if(v==="pm")renderPM();
  if(v==="cs")renderCS();
  window.scrollTo(0,0);
}
function hubProg(){
  const pmA=PM_QS.filter(q=>pmState[q.id]!==undefined&&pmState[q.id]!=="").length;
  const csA=CS_QS.filter(q=>csState[q.id]!==undefined&&csState[q.id]!=="").length;
  let pm="Not started", cs="Not started", cl="No list generated";
  if(pmA){const d=pmA>=4?pmDocList():[];const dn=d.filter(x=>pmDone[x.id]).length;
    pm=`In progress \u2014 ${pmA} of ${PM_QS.length} answered`+(d.length?` \u00b7 ${dn} of ${d.length} documents done`:"");}
  if(csA){const d=csA>=3?csDocList():[];const dn=d.filter(x=>csDone[x.id]).length;
    cs=`In progress \u2014 ${csA} of ${CS_QS.length} answered`+(d.length?` \u00b7 ${dn} of ${d.length} documents done`:"")+(csPkg?" \u00b7 package imported":"");}
  if(results)cl=`${results.length} in list \u00b7 ${screened?screened.length:0} screened`;
  return {pm,cs,cl,pmIdle:!pmA,csIdle:!csA,clIdle:!results};
}
function renderHub(){
  const host=document.getElementById("hub"); if(!host)return;
  const P=hubProg();
  host.innerHTML=`<div class="hubstamp">For testing only</div><div class="hubhead"><h1>Acquisition Package Tool</h1>
    <div class="hubsub">One offline file \u00b7 three stations \u00b7 the package travels through all of them</div></div>
  ${officeBlockHTML()}
  <div class="hubroute">
    <div class="hubcard" role="button" tabindex="0" onclick="showView('pm')" onkeydown="if(event.key==='Enter')showView('pm')">
      <span class="hubtab">PM</span><h2>Start a requirements package</h2>
      <p>Answer what you're buying; get the documentation list your package needs \u2014 IGCE, description document, funding letter, and the right competition justification \u2014 each with the reason.</p>
      <div class="hubprog${P.pmIdle?" idle":""}">${P.pm}</div>
      <span class="hubstat live">Open station</span></div>
    <div class="hubhand">package file \u2933 <small>answers and document status carry into the acquisition</small></div>
    <div class="hubcard" role="button" tabindex="0" onclick="showView('cs')" onkeydown="if(event.key==='Enter')showView('cs')">
      <span class="hubtab alt">CO / CS</span><h2>Start an acquisition from a package</h2>
      <p>Import the PM's package; answer SAT band, commercial posture, vehicle, and method; get the contracting documentation list \u2014 2597 coordination, strategy document, justification, negotiation memoranda \u2014 each with the reason.</p>
      <div class="hubprog${P.csIdle?" idle":""}">${P.cs}</div>
      <span class="hubstat live">Open station</span></div>
    <div class="hubhand">acquisition profile \u2933 <small>prefills the clause wizard \u2014 nothing answered twice</small></div>
    <div class="hubcard" role="button" tabindex="0" onclick="showView('clauses')" onkeydown="if(event.key==='Enter')showView('clauses')">
      <span class="hubtab">52.</span><h2>Build the clause list</h2>
      <p>The clause and provision selector your team is validating \u2014 profile wizard, screening, CO determinations, parent IDIQ/BPA handling, fill-ins, validation mode, and the printable attachments.</p>
      <div class="hubprog${P.clIdle?" idle":""}">${P.cl}</div>
      <span class="hubstat live">Open station</span></div>
  </div>
  <div class="hubprintbar"><button class="ghost" onclick="printCoverSheet()">Print package cover sheet</button></div>
  <div class="hubfoot"><span>Build v42 \u00b7 ${esc(MATRIX_LABEL)}${officeName?` \u00b7 ${esc(officeName)}`:""}</span><span>Single file \u00b7 no server \u00b7 no data leaves the browser</span></div>`;
}
function renderApp(){
  renderHub();
  renderHeader(); renderWizard();
  showView(currentView);
}
