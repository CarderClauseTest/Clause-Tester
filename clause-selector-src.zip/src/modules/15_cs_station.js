/* ===== MODULE 15: cs_station ===== */
/* CO/CS station — acquisition documentation from a received package.
   Catalog is data: template/guidance fields attach later without engine changes.
   Best-reading expansions (correct in this catalog): SAM = registration & exclusions
   check · PPNM = pre-negotiation objectives memo · COMBO = combined synopsis/solicitation. */
const CS_DOCS = {
  c2597:{name:"2597 Coordination", full:"Small business coordination — routing level depends on SAT", owner:"CS / Small Business"},
  samck:{name:"SAM check", full:"SAM registration & exclusions verification (award prerequisite)", owner:"CS"},
  mrrcs:{name:"Market research memo", full:"Confirm / supplement the market research received in the package", owner:"CS, with PM"},
  cid:  {name:"Commercial item determination", full:"Documents the commercial-product/-service determination", owner:"CO"},
  sass: {name:"Streamlined Acquisition Strategy Summary", full:"In lieu of a full ASP below the office plan threshold", owner:"CS, with CO"},
  ppnm: {name:"PPNM", full:"Pre-negotiation objectives memorandum", owner:"CS / CO"},
  pnm:  {name:"PNM", full:"Price negotiation memorandum — record of negotiation and price reasonableness", owner:"CS / CO"},
  abs:  {name:"Abstract", full:"Abstract of quotes / offers received", owner:"CS"},
  combo:{name:"COMBO", full:"Combined synopsis/solicitation (streamlined commercial procedures)", owner:"CS"},
  rfql: {name:"RFQ / solicitation language", full:"Solicitation package language (template attaches later)", owner:"CS"},
  evalf:{name:"Evaluation factors recommendation", full:"LPTA / tradeoff / comparative — recommended approach and factors", owner:"CS, with PM"},
  resp: {name:"Responsibility determination", full:"Affirmative determination the prospective awardee is responsible", owner:"CO"},
  prr:  {name:"Price reasonableness memo", full:"Documents price fair & reasonable where no PNM is prepared", owner:"CS"},
  awdn: {name:"Award & unsuccessful notices", full:"Notice of award and notifications to unsuccessful offerors/quoters", owner:"CS"},
  debf: {name:"Debriefing documentation", full:"Debriefings offered and conducted, with records", owner:"CS / CO"},
  cor:  {name:"COR designation", full:"COR nomination accepted and appointment letter issued", owner:"CO, with PM"},
  fpds: {name:"FPDS report (CAR)", full:"Contract action report filed in FPDS", owner:"CS"},
  presyn:{name:"Pre-award synopsis", full:"Public notice of the proposed action, posted before solicitation", owner:"CS"},
  postsyn:{name:"Post-award synopsis", full:"Public announcement of the award where required", owner:"CS"},
  synex:{name:"Synopsis exemption memo", full:"Documents the exception relied on for not synopsizing", owner:"CS / CO"},
};
const csState={}; const csDone={}; const csNotes={}; const csMeta={program:"",cs:""}; let csPkg=null; const csRecv={}; const csPM={};

const CS_QS = [
  {id:"val", q:"Action value (total, all options)?", money:true},
  {id:"sat", q:"Value relative to the simplified acquisition threshold?", help:"Drives 2597 routing, strategy document, and negotiation memoranda.", opts:[["micro","Micro-purchase level"],["under","At / under SAT"],["over","Over SAT"]]},
  {id:"comm", q:"Commercial posture?", opts:[["cp","Commercial product"],["csvc","Commercial service"],["cots","COTS"],["nc","Noncommercial"]]},
  {id:"buy", q:"What is being bought?", opts:[["sup","Supplies / equipment"],["svc","Services"],["rd","Research & development"],["con","Construction"],["it","IT / software"]]},
  {id:"vehicle", q:"Vehicle?", opts:[["open","Open market (new contract)"],["fss","GSA / Federal Supply Schedule"],["mac","Existing multiple-award IDIQ (MAC/GWAC)"],["single","Existing single-award IDIQ"],["bpa","Existing BPA (call/order)"],["ota","Other Transaction (OTA)"],["cso","Commercial Solutions Opening"],["mod","Modify an existing contract"],["sbir3","SBIR/STTR Phase III follow-on"],["unsure","Not sure yet"]]},
  {id:"comp", q:"Competition?", opts:[["full","Full competition"],["brand","Brand-name limit"],["sole","Single source"],["unsure","Undecided"]]},
  {id:"method", q:"Solicitation method?", opts:[["rfq","RFQ (simplified)"],["rfp","RFP (negotiated)"],["sealed","Sealed bid (IFB)"],["order","Order against the vehicle"]]},
  {id:"sbir", q:"SBIR/STTR-derived work?", opts:[["yes","Yes"],["no","No"],["unsure","Unsure"]]},
];

const CS_PHASES=[["pre","Pre-solicitation"],["sol","Solicitation"],["preaw","Pre-award"],["award","Award"]];
function csDocList(){
  const CAT={...PM_DOCS,...CS_DOCS};
  const out=[]; const add=(id,why,group)=>out.push({id,why,group,...CAT[id]});
  const sat=csState.sat;
  // ---- pre-solicitation ----
  add("c2597", sat==="over"?"Over SAT — routes through the small business specialist."
      : sat==="under"||sat==="micro"?"At/under SAT — may be coordinated at the CO level."
      : "Routing level depends on SAT — set the value band above.","pre");
  add("mrrcs","Underpins strategy, set-aside posture, and any justification below.","pre");
  const v=typeof csState.val==="number"?csState.val:null;
  if(v!==null&&v>=ASP_THRESHOLD)add("asp",`Value meets the written acquisition-strategy-plan threshold ($${(ASP_THRESHOLD/1e6)}M — office-set).`,"pre");
  else if(sat&&sat!=="micro")add("sass","Below the plan threshold — streamlined summary in lieu of a full ASP (confirm office practice).","pre");
  if(csState.comm==="cp"||csState.comm==="csvc")add("cid","Commercial (non-COTS) — document the commercial determination.","pre");
  for(const e of vehCompDocs({veh:csState.vehicle,comp:csState.comp,sbir:csState.sbir,followon:csState.newreq==="follow"})){
    const ph=e.id==="cso"?"sol":"pre";
    if(e.pseudo){e.pseudo.group=ph;out.push(e.pseudo);} else add(e.id,e.why,ph);
  }
  const m=csState.method;
  if(csState.comp==="full"&&(m==="rfq"||m==="rfp"))add("evalf","Competitive — recommend the evaluation approach and factors before drafting the solicitation.","pre");
  // ---- synopsis / posting: either the notices or a documented exception ----
  {
    const veh=csState.vehicle, mm=csState.method, limited=(csState.comp==="sole"||csState.comp==="brand");
    const existingVeh=["fss","mac","single","bpa","mod"].includes(veh)||mm==="order";
    const commercialOpen=(csState.comm==="cp"||csState.comm==="csvc"||csState.comm==="cots")&&veh==="open";
    if(sat==="micro"){
      add("synex","Micro-purchase level \u2014 synopsis not required; note the basis in the file.","pre");
    } else if(veh==="ota"){
      add("synex","Other Transaction \u2014 FAR synopsis rules don't attach; document agency posting practice.","pre");
    } else if(veh==="sbir3"){
      add("synex","SBIR Phase III basis \u2014 document whether notice is required or excepted; confirm with the CO.","pre");
    } else if(existingVeh){
      add("synex","Order under an existing vehicle \u2014 notice is satisfied by the vehicle's procedures; memo the exception."+(limited?" Limiting sources: confirm any posting requirement for the justification.":""),"pre");
    } else if(veh==="cso"){
      add("presyn","The CSO announcement itself is the public notice \u2014 post per the CSO procedure.","sol");
    } else if(veh){
      if(veh==="unsure")add("presyn","Vehicle undecided \u2014 the posting requirement follows the vehicle; resolve before solicitation.","sol");
      else if(commercialOpen)add("presyn","Satisfied by the combined synopsis/solicitation \u2014 one posting does both.","sol");
      else if(limited)add("presyn","Notice of the proposed limited-source action; the justification posting requirement attaches \u2014 confirm timing with the CO.","sol");
      else add("presyn","Post the opportunity before issuing the solicitation; confirm current timing thresholds.","sol");
      if(veh!=="unsure"&&(sat==="over"||limited))add("postsyn",limited?"Limited-competition award \u2014 publicize the award and justification as required.":"Over SAT \u2014 announce the award where required; confirm current thresholds.","award");
    }
  }
  // ---- solicitation ----
  if((csState.comm==="cp"||csState.comm==="csvc"||csState.comm==="cots")&&csState.vehicle==="open")
    add("combo","Commercial on the open market — streamlined combined synopsis/solicitation may fit.","sol");
  if(m==="rfq")add("rfql","RFQ planned — solicitation language to assemble.","sol");
  // ---- pre-award ----
  add("samck","Verify registration and run the exclusions check before award.","preaw");
  add("resp","Affirmative determination of responsibility is required before every award.","preaw");
  if(m==="rfp"){add("ppnm","Negotiated procurement — document pre-negotiation objectives.","preaw");
                add("pnm","Negotiated procurement — record the negotiation and price reasonableness.","preaw");}
  else if(csState.comp==="sole"&&sat==="over")add("pnm","Sole source over SAT — record the negotiation and price reasonableness.","preaw");
  if(m==="rfq"||m==="sealed")add("abs",(m==="sealed"?"Sealed bidding — abstract the offers received.":"Quotes received — abstract them for the file."),"preaw");
  if(!out.some(d=>d.id==="pnm"))add("prr","No PNM on this path — document price fair and reasonable for the file.","preaw");
  // ---- award ----
  if(csState.comp==="full")add("awdn","Competitive action — notify the awardee and unsuccessful offerors/quoters.","award");
  if(m==="rfp"&&csState.comp==="full")add("debf","Negotiated competitive — offer and document debriefings.","award");
  if(csState.buy==="svc"||csState.buy==="con")add("cor","Surveillance needed — designate the COR and issue the appointment letter.","award");
  add("fpds","Report the action in FPDS — confirm exemptions at the micro-purchase level.","award");
  return out;
}

function csImport(file){
  const r=new FileReader();
  r.onload=()=>{try{
    const pkg=JSON.parse(r.result);
    if(pkg.kind!=="acq-package")throw 0;
    csPkg=pkg;
    const a=pkg.answers||{};
    for(const k in csPM)delete csPM[k]; Object.assign(csPM,a);
    if(typeof a.val==="number"){csState.val=a.val; if(!csState.sat)csState.sat=a.val<=350000?"under":"over";}
    for(const k of ["buy","vehicle","comp","sbir","newreq"])if(a[k])csState[k]=a[k];
    csMeta.program=(pkg.meta&&pkg.meta.program)||csMeta.program;
    dirty=true; renderCS();
  }catch(e){alert("Not a package file from the PM station.");}};
  r.readAsText(file);
}

function csExpectedDocs(){
  const ans={desc:"unsure",...csPM};
  for(const k of ["buy","vehicle","comp","sbir","newreq"])if(csState[k]!==undefined)ans[k]=csState[k];
  if(typeof csState.val==="number")ans.val=csState.val;
  return pmDocsFor(ans);
}
function pkgStatus(id){
  if(!csPkg)return null;
  const m=(csPkg.docs||[]).find(d=>d.id===id);
  return m?(m.done?"done":"open"):"missing";
}
/* milestone schedule — default durations are office placeholders; adjust per row or in CS_PALT */
const CS_PALT={
  rfp:[["Pre-solicitation documents complete",10],["RFP released",7],["Questions & answers closed",10],["Proposals due",30],["Evaluations complete",21],["Negotiations / FPR complete",14],["PNM complete",7],["Award",7]],
  rfq:[["Pre-solicitation documents complete",7],["RFQ released",5],["Quotes due",10],["Abstract & evaluation complete",7],["Award",5]],
  sealed:[["Pre-solicitation documents complete",10],["IFB released",7],["Bid opening",30],["Abstract & responsiveness review",7],["Award",7]],
  order:[["Order requirements package complete",5],["Notice / RFQ to vehicle holders",5],["Responses due",10],["Evaluation complete",7],["Order awarded",5]],
};
const csPalt={}; // per-step day overrides, key: method+index
function fmtD(d){return d.toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"});}
function addD(d,n){const x=new Date(d);x.setDate(x.getDate()+n);return x;}
function csMilestones(){
  const m=csState.method; if(!m||!CS_PALT[m])return null;
  const steps=CS_PALT[m].map(([name,days],i)=>({name,days:csPalt[m+"_"+i]!==undefined?csPalt[m+"_"+i]:days,i}));
  let rows;
  if(csState.award){
    const [y,mo,da]=csState.award.split("-").map(Number);
    let cursor=new Date(y,mo-1,da);
    rows=[...steps].reverse().map(s=>{const r={...s,date:new Date(cursor)};cursor=addD(cursor,-s.days);return r;}).reverse();
  } else {
    let cursor=new Date();
    rows=steps.map(s=>{cursor=addD(cursor,s.days);return {...s,date:new Date(cursor)};});
  }
  return rows;
}
function csMilestonesHTML(){
  const rows=csMilestones();
  let h=`<h2 class="pmgrp">Milestone schedule</h2>
  <div class="msbar"><label>Target award date <input type="date" value="${esc(csState.award||"")}" onchange="csState.award=this.value;dirty=true;renderCS();"></label>
  <span class="pmfull">${csState.award?"Back-planned from the award date.":"No award date set \u2014 forward-planned from today."} Durations are office placeholders \u2014 adjust per step.</span></div>`;
  if(!rows)return h+`<p class="pmhint" style="margin:6px 0 16px">Pick a solicitation method to generate the schedule.</p>`;
  const span=Math.round((rows[rows.length-1].date-rows[0].date)/864e5);
  h+=`<div class="msline">Span <b>${span} days</b> \u00b7 begins ${fmtD(rows[0].date)} \u00b7 ends ${fmtD(rows[rows.length-1].date)}</div>`;
  h+=`<table class="mstbl"><thead><tr><th>Milestone</th><th>Days</th><th>Target date</th></tr></thead><tbody>`;
  for(const r of rows)h+=`<tr><td>${esc(r.name)}</td><td><input type="number" min="0" value="${r.days}" onchange="csPalt['${csState.method}_${r.i}']=Math.max(0,parseInt(this.value)||0);dirty=true;renderCS();"></td><td class="msdate">${fmtD(r.date)}${[0,6].includes(r.date.getDay())?` <span class="wknd">wknd</span>`:""}</td></tr>`;
  h+=`</tbody></table>`;
  return h;
}

function renderCS(){
  const host=document.getElementById("csview"); if(!host)return;
  let h=`<div class="pmhead"><button class="ghost" onclick="showView('hub')">&#8962; Hub</button>
    <h1>CO/CS station — acquisition documentation</h1>
    <p class="pmsub">Import the PM's package (or answer directly); the tool returns the contracting documentation the action needs, each with the reason.</p></div>`;
  h+=`<div class="pmmeta">
    <label class="ghost csimp">Import package (.json)<input type="file" accept=".json" style="display:none" onchange="if(this.files[0])csImport(this.files[0])"></label>
    <input type="text" placeholder="Program / requirement name" value="${esc(csMeta.program)}" oninput="csMeta.program=this.value;dirty=true">
    <input type="text" placeholder="Specialist name" value="${esc(csMeta.cs)}" oninput="csMeta.cs=this.value;dirty=true"></div>`;
  if(csPkg){
    const pend=(csPkg.docs||[]).filter(d=>!d.done);
    h+=`<div class="csintake">Package imported: <b>${esc((csPkg.meta&&csPkg.meta.program)||"unnamed")}</b> — ${(csPkg.docs||[]).length} PM documents, ${pend.length?`<b>${pend.length} not marked done</b>: ${pend.map(d=>esc(d.name)).join(", ")}`:"all marked done"}.</div>`;
    if(csPkg.flags&&csPkg.flags.length)h+=`<div class="rdy" style="margin-top:-8px">${csPkg.flags.map(f=>`<div class="rdyrow ${esc(f.level)}"><b>PM flag</b> ${esc(f.msg)}</div>`).join("")}</div>`;
  }
  for(const q of CS_QS){
    const a=csState[q.id];
    h+=`<div class="q ${a!==undefined&&a!==""?"done":""}"><div class="qt">${esc(q.q)}</div>${q.help?`<div class="qh">${esc(q.help)}</div>`:""}`;
    if(q.money){
      h+=`<input type="text" placeholder="e.g. 2.5M or 750K" value="${typeof a==="number"?("$"+a.toLocaleString()):""}"
        onchange="const v=parseMoney(this.value); if(v!==null){csState.val=v; if(!csState.sat)csState.sat=v<=350000?'under':'over'; dirty=true;renderCS();}">`;
    } else {
      h+=`<div class="opts">${q.opts.map(([v,l])=>`<button class="opt ${a===v?"sel":""}" onclick="csState.${q.id}='${v}';dirty=true;renderCS();">${esc(l)}</button>`).join("")}</div>`;
    }
    h+=`</div>`;
  }
  const answered=CS_QS.filter(q=>csState[q.id]!==undefined&&csState[q.id]!=="").length;
  if(answered>=3||csPkg){
    h+=tplChipsRO();
    const exp=csExpectedDocs(); const rec=exp.filter(d=>csRecv[d.id]).length;
    h+=`<div class="pmdocs"><h2 class="pmgrp">Files expected from the PM <span class="pmgrpct">${rec} of ${exp.length} received</span></h2>
    <p class="pmsub" style="margin:-2px 0 8px">Derived from this acquisition's answers using the PM station's own engine${csPkg?" and checked against the imported package":""}. Mark each as received when verified.</p>`;
    h+=exp.map(d=>{const st=pkgStatus(d.id);
      const chip=st==="done"?`<span class="cschip ok">in package \u00b7 done</span>`
        :st==="open"?`<span class="cschip warn">in package \u00b7 not marked done</span>`
        :st==="missing"?`<span class="cschip miss">not in package</span>`
        :`<span class="cschip">expected</span>`;
      return `<div class="row pmrow">
        <label class="pmchk" title="Received / verified"><input type="checkbox" ${csRecv[d.id]?"checked":""} onchange="csRecv['${d.id}']=this.checked?1:0;dirty=true;renderCS();"></label>
        <span><b class="pmname">${esc(d.name)}</b> <span class="pmfull">${esc(d.full)}</span> ${chip}<br>
          <span class="pmwhy">${esc(d.why)}</span>${docNoteHTML(d.id)}</span></div>`;}).join("");
    h+=`</div>`;
  }
  if(answered>=3){
    const docs=csDocList(); const stat=docs.filter(d=>csDone[d.id]).length;
    h+=`<div class="pmdocs"><div class="summary"><b>${docs.length}</b> documents for this acquisition &nbsp;\u00b7&nbsp; ${stat} marked done
      <span style="float:right"><button class="primary" onclick="printCSChecklist()">Print acquisition checklist</button>
      <button class="ghost" onclick="csToClauses()">Continue to clause station \u2192</button></span></div>`;
    for(const grp of CS_PHASES){
      const rows=docs.filter(d=>d.group===grp[0]); if(!rows.length)continue;
      const gd=rows.filter(d=>csDone[d.id]).length;
      const gated=gd===rows.length;
      h+=`<h2 class="pmgrp${gated?" gated":""}">${grp[1]} <span class="pmgrpct">${gd} of ${rows.length}</span>${gated?`<span class="gate">phase complete \u2713</span>`:""}</h2>`;
      h+=rows.map(d=>`<div class="row pmrow">
        <label class="pmchk"><input type="checkbox" ${csDone[d.id]?"checked":""} onchange="csDone['${d.id}']=this.checked?1:0;dirty=true;renderCS();"></label>
        <span><b class="pmname">${esc(d.name)}</b> <span class="pmfull">${esc(d.full)}</span><br>
          <span class="pmwhy">${esc(d.why)}</span> <span class="pmown">\u00b7 ${esc(d.owner)}</span>${docNoteHTML(d.id)}<br>
          <input type="text" class="pmnote" placeholder="working note (optional)" value="${esc(csNotes[d.id]||"")}" oninput="csNotes['${d.id}']=this.value;dirty=true">
        </span></div>`).join("");
    }
    h+=csMilestonesHTML();
    h+=`</div>`;
  } else {
    h+=`<p class="pmhint">Import a package or answer at least three questions to see the documentation list.</p>`;
  }
  host.innerHTML=h;
}

const CS_L={sat:{micro:"Micro-purchase",under:"At / under SAT",over:"Over SAT"},
  comm:{cp:"Commercial product",csvc:"Commercial service",cots:"COTS",nc:"Noncommercial"},
  method:{rfq:"RFQ (simplified)",rfp:"RFP (negotiated)",sealed:"Sealed bid",order:"Order against vehicle"}};
function printCSChecklist(){
  const docs=csDocList();
  const today=new Date().toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"});
  const vline=typeof csState.val==="number"?"$"+csState.val.toLocaleString():"\u2014";
  const done=docs.filter(d=>csDone[d.id]).length;
  const pending=docs.filter(d=>!csDone[d.id]).map(d=>d.name);
  let h=`<div class="pd-head"><h1>Acquisition Documentation Checklist \u2014 Contracting</h1>
    <div class="pd-sub">${officeName?esc(officeName)+" \u00b7 ":""}${esc(csMeta.program||"(program not named)")} \u00b7 prepared ${today}</div></div>
  <div class="pms">
    <span><b>Program</b>${esc(csMeta.program||"\u2014")}</span>
    <span><b>Specialist</b>${esc(csMeta.cs||"\u2014")}</span>
    <span><b>Value</b>${vline}</span>
    <span><b>SAT band</b>${esc(CS_L.sat[csState.sat]||"\u2014")}</span>
    <span><b>Commercial</b>${esc(CS_L.comm[csState.comm]||"\u2014")}</span>
    <span><b>Buying</b>${esc(PM_L.buy[csState.buy]||"\u2014")}</span>
    <span><b>Vehicle</b>${esc(PM_L.vehicle[csState.vehicle]||"\u2014")}</span>
    <span><b>Competition</b>${esc(PM_L.comp[csState.comp]||"\u2014")}</span>
    <span><b>Method</b>${esc(CS_L.method[csState.method]||"\u2014")}</span>
    <span><b>SBIR-derived</b>${esc(PM_L.yn[csState.sbir]||"\u2014")}</span>
    <span><b>Package</b>${csPkg?"Imported":"\u2014"}</span>
    <span><b>Date</b>${today}</span>
  </div>
  <div class="pmsline"><b>${done} of ${docs.length}</b> documents prepared${pending.length?` \u00b7 <b>Outstanding:</b> ${pending.map(esc).join(", ")}`:" \u00b7 documentation complete"}</div>`;
  const exp=csExpectedDocs(); const rec=exp.filter(d=>csRecv[d.id]).length;
  if(exp.length){
    h+=`<h2>Inputs from the PM package \u2014 ${rec} of ${exp.length} received</h2>
    <table><colgroup><col style="width:128pt"><col><col style="width:104pt"><col style="width:40pt"></colgroup>
    <thead><tr><th>Document</th><th>Why expected</th><th>Package</th><th class="pd-uc">Recd</th></tr></thead><tbody>`;
    for(const d of exp){const st=pkgStatus(d.id);
      const ps=st==="done"?"\u2713 done":st==="open"?"not marked done":st==="missing"?"not in package":"\u2014";
      h+=`<tr><td class="pd-no">${esc(d.name)}</td><td>${esc(d.why)}${docNote(d.id)?` <i>Office: ${esc(docNote(d.id))}</i>`:""}</td><td>${ps}</td><td class="pd-uc">${csRecv[d.id]?"\u2611":"\u2610"}</td></tr>`;}
    h+=`</tbody></table>`;
  }
  for(const grp of CS_PHASES){
    const rows=docs.filter(d=>d.group===grp[0]); if(!rows.length)continue;
    const gd=rows.filter(d=>csDone[d.id]).length;
    h+=`<h2>${grp[1]} \u2014 ${gd} of ${rows.length} prepared</h2>
    <table><colgroup><col style="width:128pt"><col><col style="width:92pt"><col style="width:34pt"></colgroup>
    <thead><tr><th>Document</th><th>Why</th><th>Owner</th><th class="pd-uc">Status</th></tr></thead><tbody>`;
    for(const d of rows)h+=`<tr><td class="pd-no">${esc(d.name)}</td><td>${esc(d.why)}${docNote(d.id)?` <i>Office: ${esc(docNote(d.id))}</i>`:""}${csNotes[d.id]?` <i>\u2014 ${esc(csNotes[d.id])}</i>`:""}</td><td>${esc(d.owner)}</td><td class="pd-uc">${csDone[d.id]?"\u2611":"\u2610"}</td></tr>`;
  h+=`</tbody></table>`;}
  const ms=csMilestones();
  if(ms){h+=`<h2>Milestone schedule${csState.award?" \u2014 award "+esc(csState.award):" \u2014 from today"}</h2>
    <table><colgroup><col><col style="width:50pt"><col style="width:90pt"></colgroup>
    <thead><tr><th>Milestone</th><th class="pd-uc">Days</th><th>Target date</th></tr></thead><tbody>`;
    for(const r of ms)h+=`<tr><td>${esc(r.name)}</td><td class="pd-uc">${r.days}</td><td class="pd-dt">${fmtD(r.date)}${[0,6].includes(r.date.getDay())?" (wknd)":""}</td></tr>`;
    h+=`</tbody></table>`;}
    h+=`<div class="pd-note">Generated from the CO/CS questionnaire \u2014 confirm against office procedures. Documents are grouped by phase. 2597 routing follows the SAT band; ASP/SASS follows the plan threshold; PPNM/PNM follow negotiated method; responsibility determination and FPDS reporting attach to every award.</div>
  ${templateLinks.length?`<div class="pd-note"><b>Templates:</b> ${templateLinks.map(v=>esc(v)).join(" \u00b7 ")}</div>`:""}
  <div class="pd-sig"><div>Contract Specialist: ______________________________ &nbsp;&nbsp; Contracting Officer: ______________________________ &nbsp;&nbsp; Date: ____________</div></div>`;
  const pd=document.getElementById("printdoc"); pd.innerHTML=h;
  document.body.classList.add("printing"); window.print();
  setTimeout(()=>{document.body.classList.remove("printing");},300);
}

function csToClauses(){
  if(typeof csState.val==="number")state.value=csState.val;
  const pmap={sup:"nsup",svc:"nsvc",rd:"rd",con:"con"};
  if(csState.comm==="cp")state.purpose="csup";
  else if(csState.comm==="csvc")state.purpose="csvc";
  else if(pmap[csState.buy])state.purpose=pmap[csState.buy];
  if(csState.comm==="cp"||csState.comm==="csvc"||csState.comm==="cots")state.comm="C"; else if(csState.comm==="nc")state.comm="N";
  if(csState.comm==="cots")state.cots="yes"; else if(csState.comm==="cp"||csState.comm==="csvc")state.cots="no";
  const mmap={rfq:"sap",rfp:"neg",sealed:"sld"};
  if(mmap[csState.method])state.method=mmap[csState.method];
  state.doctype="prime_sol";
  showView("clauses"); renderWizard();
  const tm=document.getElementById("toolmsg"); if(tm){tm.textContent="Profile seeded from the acquisition \u2014 confirm each answer."; setTimeout(()=>tm.textContent="",4000);}
}
