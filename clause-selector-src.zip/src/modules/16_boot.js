/* ===== MODULE 16: boot ===== */
window.addEventListener("scroll",()=>{const b=document.getElementById("totop");if(b)b.style.display=window.scrollY>600?"block":"none";});
let dirty=false;
window.addEventListener("beforeunload",e=>{if(dirty){e.preventDefault();e.returnValue="";}});
renderApp();
